package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BenchmarkSessionReport
import com.example.data.SessionAggregateSummary
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun SessionAnalyticsOverviewCard(
    summary: SessionAggregateSummary
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("reports_analytics_overview_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Insights,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Session Analytics Overview",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Last 24h",
                    value = "${summary.dailySessionCount} runs",
                    subvalue = formatDurationShort(summary.dailyTotalDurationSec),
                    accentColor = NeonCyan
                )
                AnalyticsMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Last 7 Days",
                    value = "${summary.weeklySessionCount} runs",
                    subvalue = formatDurationShort(summary.weeklyTotalDurationSec),
                    accentColor = NeonPurple
                )
                AnalyticsMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Avg Length",
                    value = formatDurationShort(summary.averageDurationSec),
                    subvalue = "Per session",
                    accentColor = NeonGreen
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Avg Est. Battery Drain",
                    value = summary.averageEstimatedDrainPercent?.let {
                        String.format(Locale.US, "%.1f%%", it)
                    } ?: "N/A (Charged)",
                    subvalue = "Discharging runs",
                    accentColor = NeonOrange
                )
                AnalyticsMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Avg Peak Temp",
                    value = summary.averagePeakTempC?.let {
                        String.format(Locale.US, "%.1f°C", it)
                    } ?: "N/A",
                    subvalue = "Battery sensor",
                    accentColor = if ((summary.averagePeakTempC ?: 0f) >= 40f) NeonRed else NeonGreen
                )
            }
        }
    }
}

@Composable
private fun AnalyticsMetricBox(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    subvalue: String,
    accentColor: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = label,
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                color = accentColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subvalue,
                color = TextSecondary,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SessionComparisonAndChartCard(
    sessions: List<BenchmarkSessionReport>,
    maxSessionsCount: Int = 10
) {
    if (sessions.isEmpty()) return

    var selectedPrimaryIndex by remember(sessions) { mutableIntStateOf(0) }
    var selectedCompareIndex by remember(sessions) {
        mutableIntStateOf(if (sessions.size > 1) 1 else 0)
    }

    val safePrimary = sessions.getOrElse(selectedPrimaryIndex) { sessions.first() }
    val safeCompare = sessions.getOrElse(selectedCompareIndex) { safePrimary }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("reports_comparison_chart_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ShowChart,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Temperature Curve & Session Compare",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            // Session A selector
            Text("Primary Session (Chart)", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sessions.take(maxSessionsCount).forEachIndexed { idx, session ->
                    FilterChip(
                        selected = idx == selectedPrimaryIndex,
                        onClick = { selectedPrimaryIndex = idx },
                        label = {
                            Text(
                                text = session.sessionLabel.take(20),
                                fontSize = 10.5.sp,
                                maxLines = 1
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                            selectedLabelColor = NeonCyan
                        )
                    )
                }
            }

            // Temperature Curve Canvas
            val snapshots = safePrimary.snapshots
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = DarkSurfaceVariant
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${safePrimary.gameTitle} • Temp Telemetry",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        val hasPrimaryTemp = safePrimary.startTempC > 0f && safePrimary.peakTempC > 0f
                        Text(
                            text = if (hasPrimaryTemp) "${safePrimary.startTempC}°C → ${safePrimary.peakTempC}°C" else "N/A",
                            color = if (!hasPrimaryTemp) TextSecondary else if (safePrimary.peakTempC >= 40f) NeonOrange else NeonGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val validTempSnapshots = remember(snapshots) {
                        snapshots.filter { it.batteryTempC > 0f }
                    }
                    if (validTempSnapshots.size >= 2) {
                        val minT = (validTempSnapshots.minOf { it.batteryTempC } - 1f).coerceAtLeast(20f)
                        val maxT = (validTempSnapshots.maxOf { it.batteryTempC } + 1f).coerceAtLeast(minT + 4f)
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                        ) {
                            val w = size.width
                            val h = size.height
                            // Subtle horizontal reference grid
                            for (i in 0..2) {
                                val y = h * (i / 2f)
                                drawLine(
                                    color = Color(0xFF28354E),
                                    start = Offset(0f, y),
                                    end = Offset(w, y),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }

                            val path = Path()
                            validTempSnapshots.forEachIndexed { index, snap ->
                                val x = (index.toFloat() / (validTempSnapshots.size - 1).coerceAtLeast(1)) * w
                                val norm = ((snap.batteryTempC - minT) / (maxT - minT)).coerceIn(0f, 1f)
                                val y = h - (norm * (h - 12f)) - 6f
                                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }

                            drawPath(
                                path = path,
                                color = Color(0xFF00E5FF),
                                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                            )

                            validTempSnapshots.forEachIndexed { index, snap ->
                                val x = (index.toFloat() / (validTempSnapshots.size - 1).coerceAtLeast(1)) * w
                                val norm = ((snap.batteryTempC - minT) / (maxT - minT)).coerceIn(0f, 1f)
                                val y = h - (norm * (h - 12f)) - 6f
                                val dotColor = if (snap.batteryTempC >= 41f) Color(0xFFFF5252) else Color(0xFF00E5FF)
                                drawCircle(color = dotColor, radius = 3.dp.toPx(), center = Offset(x, y))
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("0s (${validTempSnapshots.first().batteryTempC}°C)", color = TextMuted, fontSize = 10.sp)
                            Text("${validTempSnapshots.size} samples", color = TextSecondary, fontSize = 10.sp)
                            Text("${validTempSnapshots.last().elapsedSeconds}s (${validTempSnapshots.last().batteryTempC}°C)", color = TextMuted, fontSize = 10.sp)
                        }
                    } else {
                        Text(
                            text = "No time-series snapshots recorded for this baseline entry. Start a Live Benchmark Session to record per-interval sensor curves.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // 2-Session Comparison Section
            if (sessions.size >= 2) {
                HorizontalDivider(color = DarkSurfaceBorder)

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CompareArrows,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Compare With Second Session",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sessions.take(maxSessionsCount).forEachIndexed { idx, session ->
                        FilterChip(
                            selected = idx == selectedCompareIndex,
                            onClick = { selectedCompareIndex = idx },
                            label = {
                                Text(
                                    text = session.sessionLabel.take(20),
                                    fontSize = 10.5.sp,
                                    maxLines = 1
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                                selectedLabelColor = NeonCyan
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ComparisonHeaderRow(
                            leftTitle = safePrimary.sessionLabel.take(16),
                            rightTitle = safeCompare.sessionLabel.take(16)
                        )
                        HorizontalDivider(color = DarkSurfaceBorder)
                        ComparisonMetricRow(
                            metric = "Duration",
                            leftVal = formatDurationShort(safePrimary.durationSeconds),
                            rightVal = formatDurationShort(safeCompare.durationSeconds)
                        )
                        ComparisonMetricRow(
                            metric = "Peak Temp",
                            leftVal = if (safePrimary.peakTempC > 0f) "${safePrimary.peakTempC}°C" else "N/A",
                            rightVal = if (safeCompare.peakTempC > 0f) "${safeCompare.peakTempC}°C" else "N/A"
                        )
                        ComparisonMetricRow(
                            metric = "Temp Rise",
                            leftVal = if (safePrimary.startTempC > 0f && safePrimary.peakTempC > 0f) formatTempDelta(safePrimary.peakTempC - safePrimary.startTempC) else "N/A",
                            rightVal = if (safeCompare.startTempC > 0f && safeCompare.peakTempC > 0f) formatTempDelta(safeCompare.peakTempC - safeCompare.startTempC) else "N/A"
                        )
                        ComparisonMetricRow(
                            metric = "Bat. Delta",
                            leftVal = "${safePrimary.endBatteryLevel - safePrimary.startBatteryLevel}%",
                            rightVal = "${safeCompare.endBatteryLevel - safeCompare.startBatteryLevel}%"
                        )
                        ComparisonMetricRow(
                            metric = "Min Free RAM",
                            leftVal = "${safePrimary.minAvailRamGb} GB",
                            rightVal = "${safeCompare.minAvailRamGb} GB"
                        )
                        ComparisonMetricRow(
                            metric = "Avg Ping",
                            leftVal = if (safePrimary.avgPingMs > 0) "${safePrimary.avgPingMs} ms" else "N/A",
                            rightVal = if (safeCompare.avgPingMs > 0) "${safeCompare.avgPingMs} ms" else "N/A"
                        )
                        ComparisonMetricRow(
                            metric = "Throttled",
                            leftVal = if (safePrimary.throttlingObserved) "Yes" else "No",
                            rightVal = if (safeCompare.throttlingObserved) "Yes" else "No"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ComparisonHeaderRow(leftTitle: String, rightTitle: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text("Metric", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(leftTitle, color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(rightTitle, color = NeonPurple, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ComparisonMetricRow(metric: String, leftVal: String, rightVal: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(metric, color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(leftVal, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(rightVal, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
    }
}

private fun formatDurationShort(totalSeconds: Int): String {
    if (totalSeconds <= 0) return "0m"
    val mins = totalSeconds / 60
    val secs = totalSeconds % 60
    return if (mins >= 60) {
        val hrs = mins / 60
        val remMins = mins % 60
        "${hrs}h ${remMins}m"
    } else if (mins > 0) {
        "${mins}m ${secs}s"
    } else {
        "${secs}s"
    }
}

private fun formatTempDelta(delta: Float): String {
    val sign = if (delta >= 0f) "+" else ""
    return "$sign${String.format(Locale.US, "%.1f", delta)}°C"
}
