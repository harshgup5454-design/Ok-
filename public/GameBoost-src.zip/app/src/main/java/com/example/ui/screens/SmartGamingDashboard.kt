package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.smartgaming.AutopilotState
import com.example.smartgaming.BackgroundAppItem
import com.example.smartgaming.SmartGamingManager
import com.example.ui.theme.*

@Composable
fun SmartGamingDashboard(
    deviceStats: DeviceStats,
    autopilotState: AutopilotState = AutopilotState(),
    protectionStatus: GamingProtectionStatus = GamingProtectionStatus(),
    backgroundApps: List<BackgroundAppItem> = emptyList(),
    gameProfiles: List<GameProfile> = emptyList(),
    permissionActionBanner: String? = null,
    onDismissPermissionBanner: () -> Unit = {},
    onToggleAutopilotMaster: (Boolean) -> Unit = {},
    onSelectProfile: (ProfileType) -> Unit = {},
    onSelectTargetGame: (GameProfile) -> Unit = {},
    onStartSession: (ProfileType) -> Unit = {},
    onStopSession: () -> Unit = {},
    onRefreshBackgroundApps: (Context) -> Unit = {},
    onRefreshUsageStatus: (Context) -> Unit = {},
    onOpenAppSettings: (Context, String) -> Unit = { _, _ -> },
    onBackClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var isGameSelectorExpanded by remember { mutableStateOf(false) }
    var isBackgroundSectionExpanded by remember { mutableStateOf(false) }
    var isPermissionGuideExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        onRefreshUsageStatus(context)
        onRefreshBackgroundApps(context)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("smart_gaming_lazy_column"),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // TOP HEADER BAR
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("autopilot_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "GAMING AUTOPILOT 3.0",
                        color = NeonCyan,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Universal Game Detection & Safe System Profiles",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                IconButton(
                    onClick = {
                        onRefreshUsageStatus(context)
                        onRefreshBackgroundApps(context)
                    },
                    modifier = Modifier.testTag("autopilot_refresh_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextSecondary)
                }
            }
        }

        // AUTOPILOT MASTER SWITCH HERO CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(GamingBlue.copy(alpha = 0.7f), NeonCyan.copy(alpha = 0.7f), NeonPurple.copy(alpha = 0.7f))
                        ),
                        RoundedCornerShape(20.dp)
                    ),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (autopilotState.isAutopilotEnabled)
                                            Brush.linearGradient(listOf(GamingBlue, NeonCyan))
                                        else
                                            Brush.linearGradient(listOf(DarkSurfaceBorder, DarkSurfaceVariant))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoMode,
                                    contentDescription = null,
                                    tint = if (autopilotState.isAutopilotEnabled) Color.Black else TextSecondary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "AUTOPILOT MASTER",
                                    color = if (autopilotState.isAutopilotEnabled) NeonCyan else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = when {
                                        autopilotState.isSessionActive && autopilotState.wasAutoDetected -> "Auto-detected active game session"
                                        autopilotState.isSessionActive -> "Manual game session active"
                                        autopilotState.isAutopilotEnabled -> "Auto-optimization armed"
                                        else -> "Manual profile mode"
                                    },
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = autopilotState.isAutopilotEnabled,
                            onCheckedChange = { onToggleAutopilotMaster(it) },
                            modifier = Modifier.testTag("autopilot_master_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = DarkSurfaceVariant
                            )
                        )
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    // Active Target Game Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Target Game:", color = TextSecondary, fontSize = 12.sp)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier
                                .clickable(enabled = gameProfiles.isNotEmpty()) {
                                    isGameSelectorExpanded = !isGameSelectorExpanded
                                }
                                .testTag("autopilot_target_game_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = autopilotState.targetGameTitle,
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp
                                )
                                if (gameProfiles.isNotEmpty()) {
                                    Icon(
                                        imageVector = if (isGameSelectorExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = "Choose Target Game",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    AnimatedVisibility(visible = isGameSelectorExpanded && gameProfiles.isNotEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Select game (loads & remembers its profile):",
                                    color = TextMuted,
                                    fontSize = 10.5.sp
                                )
                                gameProfiles.take(10).forEach { game ->
                                    val remembered = DeviceControlEngine.mapGamePerformanceModeToProfile(game.performanceMode)
                                    val isCurrent = game.packageName == autopilotState.targetGamePackage
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                onSelectTargetGame(game)
                                                isGameSelectorExpanded = false
                                            }
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = game.name,
                                            color = if (isCurrent) NeonCyan else TextPrimary,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 11.5.sp
                                        )
                                        Text(
                                            text = remembered.autopilotTitle,
                                            color = TextSecondary,
                                            fontSize = 10.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Detection & Permission Status Pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (autopilotState.usageAccessGranted) NeonGreen else NeonOrange)
                            )
                            Text(
                                text = autopilotState.detectionStatus,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Autopilot Status Description
                    Text(
                        text = autopilotState.lastSessionSummary,
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )

                    if (!permissionActionBanner.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = NeonOrange.copy(alpha = 0.14f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonOrange.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("autopilot_permission_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = permissionActionBanner,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = {
                                        isPermissionGuideExpanded = true
                                        onDismissPermissionBanner()
                                    },
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Text("Review", color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    // LIVE SESSION TOGGLE BUTTON
                    if (!autopilotState.isSessionActive) {
                        Button(
                            onClick = { onStartSession(autopilotState.activeProfile) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("autopilot_session_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ACTIVATE ${autopilotState.activeProfile.autopilotTitle.uppercase()}",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp
                            )
                        }
                    } else {
                        Button(
                            onClick = onStopSession,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("autopilot_session_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.25f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, tint = NeonRed)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "STOP SESSION & RESTORE SETTINGS",
                                color = NeonRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // LIVE TELEMETRY & SMART THERMAL PROTECTION CARD
        item {
            val sevColor = when (protectionStatus.overallSeverity) {
                ProtectionSeverity.CRITICAL -> NeonRed
                ProtectionSeverity.WARNING -> NeonOrange
                ProtectionSeverity.ADVISORY -> NeonCyan
                ProtectionSeverity.SAFE -> NeonGreen
            }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, sevColor.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = sevColor, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Smart Protection: ${protectionStatus.headline}",
                                color = sevColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        val tempLabel = if (deviceStats.batteryTemperatureC > 0f) "${deviceStats.batteryTemperatureC}°C" else "N/A"
                        Text(
                            text = "$tempLabel • ${deviceStats.batteryLevelPercent}%",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val ramText = if (deviceStats.availableMemoryGb > 0f) {
                            "${String.format(java.util.Locale.US, "%.1f", deviceStats.availableMemoryGb)} GB Free"
                        } else {
                            "Unavailable"
                        }
                        val netText = if (autopilotState.networkLatencyMs < 0) {
                            "N/A (Not Tested)"
                        } else {
                            "${autopilotState.networkLatencyMs} ms (${autopilotState.networkType})"
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Available RAM", color = TextMuted, fontSize = 10.sp)
                                Text(ramText, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Network Ping", color = TextMuted, fontSize = 10.sp)
                                Text(netText, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                            }
                        }
                    }

                    if (protectionStatus.alerts.isEmpty()) {
                        Text(
                            text = "Battery health (${protectionStatus.batteryHealthLabel}), OS thermal status (${deviceStats.powerManagerThermalStatus}), and power headroom are normal.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    } else {
                        protectionStatus.alerts.forEach { alert ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = DarkSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(alert.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(alert.message, color = TextSecondary, fontSize = 10.5.sp)
                                    Text("Recommendation: ${alert.recommendation}", color = NeonCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3 GAMING PROFILES SELECTOR
        item {
            Text(
                text = "Optimization Profiles",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    ProfileType.SMOOTHNESS_FOCUS to Icons.Default.Security,
                    ProfileType.BALANCED to Icons.Default.Balance,
                    ProfileType.BATTERY_FRIENDLY to Icons.Default.BatterySaver
                ).forEach { (profile, icon) ->
                    val isSelected = autopilotState.activeProfile == profile
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectProfile(profile) }
                            .testTag("autopilot_profile_${profile.name.lowercase()}")
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) NeonCyan else DarkSurfaceBorder,
                                shape = RoundedCornerShape(14.dp)
                            ),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) GamingBlue.copy(alpha = 0.2f) else DarkSurface
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) NeonCyan else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = profile.autopilotTitle,
                                color = if (isSelected) NeonCyan else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // PROFILE DETAILS & HONEST APPLIED/SKIPPED SETTINGS CARD
        item {
            val profileDef = DeviceControlEngine.getProfileDefinition(autopilotState.activeProfile)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Active Profile: ${autopilotState.activeProfile.autopilotTitle}",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = profileDef.description,
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "Supported System Adjustments:\n" + profileDef.appliedAuthorizedSettings.joinToString("\n") { "• $it" },
                        color = TextPrimary,
                        fontSize = 11.sp,
                        lineHeight = 17.sp
                    )
                    Text(
                        text = "Note: In-game sensitivity, graphics presets, and FPS limits are not modified automatically due to Android sandboxing.",
                        color = TextMuted,
                        fontSize = 10.5.sp,
                        lineHeight = 15.sp
                    )

                    if (autopilotState.isSessionActive && (autopilotState.appliedSettings.isNotEmpty() || autopilotState.skippedSettings.isNotEmpty())) {
                        HorizontalDivider(color = DarkSurfaceBorder)
                        if (autopilotState.appliedSettings.isNotEmpty()) {
                            Text(
                                text = "Applied Now:\n" + autopilotState.appliedSettings.joinToString("\n") { "✓ $it" },
                                color = NeonGreen,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                        if (autopilotState.skippedSettings.isNotEmpty()) {
                            Text(
                                text = "Skipped / Unchanged:\n" + autopilotState.skippedSettings.joinToString("\n") { "• $it" },
                                color = NeonOrange,
                                fontSize = 10.5.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // PERMISSION & SETTING AUTHORIZATION GUIDE
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isPermissionGuideExpanded = !isPermissionGuideExpanded }
                            .testTag("autopilot_permissions_header"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                            Text("Official Android Permissions Status", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                        Icon(
                            imageVector = if (isPermissionGuideExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (isPermissionGuideExpanded) {
                        val canWrite = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.System.canWrite(context) else true
                        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                        val canDnd = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) nm?.isNotificationPolicyAccessGranted == true else true
                        val hasUsage = autopilotState.usageAccessGranted

                        PermissionStatusRow(
                            label = "Usage Access (Auto Game Detection)",
                            isGranted = hasUsage,
                            description = "Optional: allows Autopilot to detect when supported games open or close.",
                            onFix = {
                                val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                try { context.startActivity(intent) } catch (_: Exception) {}
                            }
                        )

                        PermissionStatusRow(
                            label = "Modify System Settings",
                            isGranted = canWrite,
                            description = "Required to adjust screen brightness and display timeout automatically.",
                            onFix = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    try { context.startActivity(intent) } catch (_: Exception) {}
                                }
                            }
                        )

                        PermissionStatusRow(
                            label = "Do Not Disturb (Notification Policy)",
                            isGranted = canDnd,
                            description = "Required to suppress notification rings and alerts during matches.",
                            onFix = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    try { context.startActivity(intent) } catch (_: Exception) {}
                                }
                            }
                        )
                    }
                }
            }
        }

        // BACKGROUND APP MANAGEMENT SECTION
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isBackgroundSectionExpanded = !isBackgroundSectionExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Apps, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(18.dp))
                            Text("Background Activity Manager", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Icon(
                            imageVector = if (isBackgroundSectionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Honest limitation notice
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = "NOTICE: Standard Android applications cannot force-stop other apps due to sandbox security. Tap any app below to open its official System Settings screen and set Battery Usage to 'Restricted' or Force Stop it manually.",
                            color = TextMuted,
                            fontSize = 10.5.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    if (isBackgroundSectionExpanded) {
                        if (backgroundApps.isEmpty()) {
                            Text("No background processes detected or apps isolated by Android.", color = TextSecondary, fontSize = 11.sp)
                        } else {
                            backgroundApps.take(6).forEach { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onOpenAppSettings(context, app.packageName) }
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(app.appName, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text(app.advice, color = TextSecondary, fontSize = 10.sp, lineHeight = 13.sp)
                                    }
                                    Icon(Icons.Default.OpenInNew, contentDescription = "Manage", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                }
                                HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionStatusRow(
    label: String,
    isGranted: Boolean,
    description: String,
    onFix: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isGranted) NeonGreen else NeonOrange)
                )
                Text(label, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
            Text(description, color = TextSecondary, fontSize = 10.5.sp)
        }
        if (!isGranted) {
            TextButton(
                onClick = onFix,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("Authorize", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
        }
    }
}
