package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.ads.*
import com.example.ui.components.AdMobAdaptiveBannerSlot
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random
import androidx.activity.compose.BackHandler

data class TargetNode(
    val id: Int,
    val initialX: Float,
    val initialY: Float,
    val radius: Float,
    val spawnTime: Long,
    val movementPattern: String // "Stationary", "Moving (Drift)", "Pulsing"
)

@Composable
fun AimIntelligenceScreen(
    savedProfiles: List<SensitivityProfile>,
    trainingHistory: List<AimTrainingSessionStats>,
    calibrationHistory: List<RotationCalibrationAttempt>,
    onSaveProfile: (SensitivityProfile) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onDuplicateProfile: (SensitivityProfile) -> Unit,
    onSaveCalibration: (RotationCalibrationAttempt) -> Unit,
    onSaveTrainingSession: (AimTrainingSessionStats) -> Unit,
    smartAimControlState: SmartAimControlState = SmartAimControlState(),
    gyroscopeState: GyroscopeTelemetry = GyroscopeTelemetry(),
    deviceSpecs: AimDeviceSpecs? = null,
    onMasterSwitchChanged: (Boolean) -> Unit = {},
    onModeSelected: (AimOptimizationMode) -> Unit = {},
    onGameSelected: (String) -> Unit = {},
    onApplyPreset: (String, AimOptimizationMode) -> Unit = { _, _ -> },
    onCalibrateGyro: () -> Unit = {},
    onSelectSavedProfile: (SensitivityProfile) -> Unit = {},
    onExportProfilesJson: () -> String = { "[]" },
    onImportProfilesJson: (String) -> Int = { 0 },
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    initialTab: Int = 0,
    onBackClick: (() -> Unit)? = null
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var selectedTab by remember(initialTab) { mutableStateOf(initialTab.coerceIn(0, 5)) } // 0 = Optimizer Control, 1 = Calculator, 2 = Rotation, 3 = Aim Trainer, 4 = Analytics, 5 = HUD
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedText by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var importInputText by remember { mutableStateOf("") }

    if (onBackClick != null) {
        BackHandler { onBackClick() }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBackClick != null) {
                        IconButton(onClick = onBackClick, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                        }
                    }
                    Icon(Icons.Default.GpsFixed, contentDescription = null, tint = NeonRed, modifier = Modifier.size(24.dp))
                    Text(
                        text = "SMART AIM & ROTATION OPTIMIZER",
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
                Text(
                    text = "Hardware sensitivity calculation, gyroscope calibration, and aim precision lab.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Navigation Sub-Tabs
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        label = { Text("Optimizer", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f), selectedLabelColor = NeonCyan),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        label = { Text("Calculator", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonPurple.copy(alpha = 0.2f), selectedLabelColor = NeonPurple),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        label = { Text("Rotation", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonGreen.copy(alpha = 0.2f), selectedLabelColor = NeonGreen),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        label = { Text("Aim Lab", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonRed.copy(alpha = 0.2f), selectedLabelColor = NeonRed),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        label = { Text("Analytics", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonPurple.copy(alpha = 0.2f), selectedLabelColor = NeonPurple),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedTab == 5,
                        onClick = { selectedTab = 5 },
                        label = { Text("HUD Guide", fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f), selectedLabelColor = NeonCyan),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Tab Content
        item {
            when (selectedTab) {
                0 -> SmartAimControlCenterSection(
                    controlState = smartAimControlState,
                    gyroState = gyroscopeState,
                    deviceSpecs = deviceSpecs,
                    savedProfiles = savedProfiles,
                    onMasterSwitchChanged = onMasterSwitchChanged,
                    onModeSelected = onModeSelected,
                    onGameSelected = onGameSelected,
                    onApplyPreset = onApplyPreset,
                    onCalibrateGyro = onCalibrateGyro,
                    onSelectProfile = onSelectSavedProfile,
                    onExportProfiles = {
                        exportedText = onExportProfilesJson()
                        showExportDialog = true
                    },
                    onImportProfiles = {
                        importInputText = ""
                        showImportDialog = true
                    }
                )
                1 -> SensitivityCalculatorSection(savedProfiles, onSaveProfile, onDeleteProfile, onDuplicateProfile)
                2 -> RotationCalibrationSection(calibrationHistory, onSaveCalibration)
                3 -> AimTrainerMiniGameSection(
                    isPremium = isPremium,
                    isAutopilotActive = isAutopilotActive,
                    thermalSeverity = thermalSeverity,
                    adManager = adManager,
                    onSaveSession = onSaveTrainingSession
                )
                4 -> AccuracyAnalyticsSection(history = trainingHistory)
                5 -> HudAdvisorSection()
            }
        }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = DarkSurface,
            title = { Text("Export Sensitivity Profiles", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Copy this JSON backup to share or restore your saved sensitivity profiles.",
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                    OutlinedTextField(
                        value = exportedText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 10.5.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboard.setText(androidx.compose.ui.text.AnnotatedString(exportedText))
                        android.widget.Toast.makeText(context, "Profiles JSON copied to clipboard", android.widget.Toast.LENGTH_SHORT).show()
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Copy JSON", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = TextSecondary)
                }
            }
        )
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = DarkSurface,
            title = { Text("Import Sensitivity Profiles", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Paste exported GAMEBOOST profile JSON below to save & apply.",
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("[{\"profileName\":\"My Profile\", ...}]", color = TextMuted, fontSize = 10.5.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 10.5.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val count = onImportProfilesJson(importInputText)
                        if (count > 0) {
                            android.widget.Toast.makeText(context, "Imported $count profile(s)", android.widget.Toast.LENGTH_SHORT).show()
                            showImportDialog = false
                        } else {
                            android.widget.Toast.makeText(context, "Invalid JSON profile format", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen)
                ) {
                    Text("Import", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun SensitivityCalculatorSection(
    savedProfiles: List<SensitivityProfile>,
    onSaveProfile: (SensitivityProfile) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onDuplicateProfile: (SensitivityProfile) -> Unit
) {
    var selectedGame by remember { mutableStateOf("BGMI / PUBG Mobile") }
    var selectedStyle by remember { mutableStateOf("Balanced") }
    var selectedDpi by remember { mutableStateOf(400) }
    var profileName by remember { mutableStateOf("Custom Pro Profile") }
    var showSavedProfiles by remember { mutableStateOf(false) }

    val games = listOf("BGMI / PUBG Mobile", "Free Fire MAX", "Call of Duty: Mobile")
    val styles = listOf("Low Sensitivity / Arm Swipes", "Balanced", "High Sensitivity / Thumb Swipes")
    val dpiTiers = listOf(320, 400, 480, 560)

    val currentProfile = remember(selectedGame, selectedStyle, selectedDpi) {
        AimIntelligenceRepository.calculateSensitivity(selectedGame, selectedStyle, selectedDpi)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Advanced Sensitivity Calculator", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                TextButton(onClick = { showSavedProfiles = !showSavedProfiles }) {
                    Text(text = if (showSavedProfiles) "Calculator" else "Saved (${savedProfiles.size})", color = NeonCyan, fontSize = 11.sp)
                }
            }

            if (showSavedProfiles) {
                Text(text = "Saved Sensitivity Profiles", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (savedProfiles.isEmpty()) {
                    Text(text = "No saved profiles yet. Save your calculated profile below.", color = TextSecondary, fontSize = 12.sp)
                } else {
                    savedProfiles.forEach { profile ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = profile.profileName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(onClick = { onDuplicateProfile(profile) }, modifier = Modifier.size(48.dp)) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = NeonCyan, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(onClick = { onDeleteProfile(profile.id) }, modifier = Modifier.size(48.dp)) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = NeonRed, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                                Text(text = "${profile.gameName} • ${profile.sensitivityStyle} • ${profile.dpiTier} DPI", color = TextSecondary, fontSize = 11.sp)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(text = "Gen: ${profile.general}", color = NeonCyan, fontSize = 11.sp)
                                    Text(text = "RedDot: ${profile.redDot}", color = NeonGreen, fontSize = 11.sp)
                                    Text(text = "2x: ${profile.scope2x}", color = NeonPurple, fontSize = 11.sp)
                                    Text(text = "4x: ${profile.scope4x}", color = NeonOrange, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                // Calculator Controls
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Select Game Title", color = TextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        games.forEach { game ->
                            FilterChip(
                                selected = selectedGame == game,
                                onClick = { selectedGame = game },
                                label = { Text(game.take(10), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f), selectedLabelColor = NeonCyan)
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Camera Movement Style", color = TextSecondary, fontSize = 12.sp)
                    styles.forEach { style ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStyle = style }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RadioButton(
                                selected = selectedStyle == style,
                                onClick = { selectedStyle = style },
                                colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                            )
                            Text(text = style, color = TextPrimary, fontSize = 12.sp)
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Device Screen DPI Tier", color = TextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        dpiTiers.forEach { dpi ->
                            FilterChip(
                                selected = selectedDpi == dpi,
                                onClick = { selectedDpi = dpi },
                                label = { Text("$dpi DPI") },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonGreen.copy(alpha = 0.2f), selectedLabelColor = NeonGreen)
                            )
                        }
                    }
                }

                HorizontalDivider(color = DarkSurfaceBorder)

                Text(text = "Recommended Scope Sensitivities", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SensBox("General", "${currentProfile.general}")
                    SensBox("Red Dot", "${currentProfile.redDot}")
                    SensBox("2x Scope", "${currentProfile.scope2x}")
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SensBox("4x Scope", "${currentProfile.scope4x}")
                    SensBox("Sniper 8x", "${currentProfile.sniper}")
                    SensBox("Free Look", "${currentProfile.freeLook}")
                }

                OutlinedTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    label = { Text("Profile Name", color = TextMuted, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = DarkSurfaceBorder),
                    singleLine = true
                )

                Button(
                    onClick = {
                        onSaveProfile(currentProfile.copy(profileName = profileName.ifBlank { "Custom Profile" }))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Save Sensitivity Profile", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(color = DarkSurfaceBorder)

                Text(text = "Transparent Algorithmic Rationale & Notice:", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(
                    text = "${currentProfile.mathematicalRationale}\n\nDisclaimer: GAMEBOOST touch recommendations are mathematical baselines. Always verify and manually test sensitivity in your in-game training room.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun SensBox(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSurfaceVariant,
        modifier = Modifier.width(100.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = label, color = TextSecondary, fontSize = 10.sp)
            Text(text = value, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun RotationCalibrationSection(
    calibrationHistory: List<RotationCalibrationAttempt>,
    onSaveCalibration: (RotationCalibrationAttempt) -> Unit
) {
    var isRecording by remember { mutableStateOf(false) }
    var startTime by remember { mutableStateOf(0L) }
    var lastAttempt by remember { mutableStateOf<RotationCalibrationAttempt?>(null) }
    var showHistory by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Touch Rotation Calibration Pad", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                TextButton(onClick = { showHistory = !showHistory }) {
                    Text(text = if (showHistory) "Calibrate" else "History (${calibrationHistory.size})", color = NeonGreen, fontSize = 11.sp)
                }
            }

            if (showHistory) {
                Text(text = "Calibration Attempts Log", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (calibrationHistory.isEmpty()) {
                    Text(text = "No calibration attempts recorded yet.", color = TextSecondary, fontSize = 12.sp)
                } else {
                    calibrationHistory.forEach { att ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(text = att.recommendedStyle, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "${att.avgSpeedPxPerSec.toInt()} px/s", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Text(text = "Duration: ${att.durationMs}ms • Consistency: ${att.consistencyScore}% • Rec Gen: ${att.recommendedGeneralSensitivity}", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            } else {
                Text(
                    text = "Swipe horizontally across the pad below at your natural aiming speed to measure velocity, swipe duration, and consistency.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                var trackedDistancePx by remember { mutableStateOf(0f) }
                var trackedNetDx by remember { mutableStateOf(0f) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceVariant)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = {
                                    startTime = System.currentTimeMillis()
                                    trackedDistancePx = 0f
                                    trackedNetDx = 0f
                                    isRecording = true
                                },
                                onDragEnd = {
                                    if (isRecording) {
                                        val duration = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
                                        val distance = trackedDistancePx
                                        if (distance >= 20f) {
                                            val speed = (distance / duration) * 1000f
                                            // Real horizontal straightness: |net horizontal displacement| / total path length
                                            val consistency = ((kotlin.math.abs(trackedNetDx) / distance) * 100f)
                                                .coerceIn(10f, 100f)

                                            val style = when {
                                                speed < 400f -> "Slow Precision Sweep"
                                                speed < 900f -> "Balanced Rotation"
                                                speed < 1500f -> "Fast Swipe"
                                                else -> "Very Fast Flick"
                                            }

                                            val genSens = when {
                                                speed < 400f -> 95
                                                speed < 900f -> 75
                                                speed < 1500f -> 55
                                                else -> 40
                                            }

                                            val attempt = RotationCalibrationAttempt(
                                                id = "cal_${System.currentTimeMillis()}",
                                                timestamp = System.currentTimeMillis(),
                                                swipeDistancePx = distance,
                                                durationMs = duration,
                                                avgSpeedPxPerSec = speed,
                                                consistencyScore = consistency,
                                                recommendedStyle = style,
                                                recommendedGeneralSensitivity = genSens,
                                                advice = "Measured ${distance.toInt()} px swipe (${speed.toInt()} px/s over ${duration}ms). Path straightness: ${consistency.toInt()}%. Recommended general sensitivity: $genSens."
                                            )
                                            lastAttempt = attempt
                                            onSaveCalibration(attempt)
                                        }
                                        isRecording = false
                                    }
                                },
                                onDragCancel = { isRecording = false },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    trackedDistancePx += hypot(dragAmount.x, dragAmount.y)
                                    trackedNetDx += dragAmount.x
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Gesture else Icons.Default.Swipe,
                            contentDescription = null,
                            tint = if (isRecording) NeonGreen else NeonCyan,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (isRecording) "Recording Swipe Velocity..." else "SWIPE HORIZONTALLY HERE",
                            color = if (isRecording) NeonGreen else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Test your thumb or arm flick speed",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                lastAttempt?.let { res ->
                    HorizontalDivider(color = DarkSurfaceBorder)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Latest Calibration Result", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Style:", color = TextSecondary, fontSize = 12.sp)
                            Text(text = res.recommendedStyle, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Velocity & Duration:", color = TextSecondary, fontSize = 12.sp)
                            Text(text = "${res.avgSpeedPxPerSec.toInt()} px/s (${res.durationMs}ms)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Consistency Score:", color = TextSecondary, fontSize = 12.sp)
                            Text(text = "${res.consistencyScore}%", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Text(text = res.advice, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AimTrainerMiniGameSection(
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onSaveSession: (AimTrainingSessionStats) -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var targetsHit by remember { mutableStateOf(0) }
    var targetsSpawned by remember { mutableStateOf(0) }
    var missCount by remember { mutableStateOf(0) }
    var currentStreak by remember { mutableStateOf(0) }
    var bestStreak by remember { mutableStateOf(0) }
    var durationSec by remember { mutableStateOf(30) }
    var timeLeft by remember { mutableStateOf(30) }
    var difficulty by remember { mutableStateOf("Medium") }
    var targetSize by remember { mutableStateOf("Medium") }
    var targetMovement by remember { mutableStateOf("Moving (Drift)") }

    var reactionTimes = remember { mutableStateListOf<Long>() }
    var currentTarget by remember { mutableStateOf<TargetNode?>(null) }
    var sessionFinished by remember { mutableStateOf(false) }
    var lastAccuracy by remember { mutableStateOf(0f) }
    var lastAvgReaction by remember { mutableStateOf(0) }

    val adState by adManager.adState.collectAsState()
    val aimVisibility = AdVisibilityContext(
        location = AdScreenLocation.AIM_TRAINER,
        isGamingSessionActive = isAutopilotActive || isPlaying,
        isAutopilotSessionActive = isAutopilotActive,
        isAimTrainingActive = isPlaying,
        thermalSeverity = thermalSeverity
    )
    val shouldShowAimBanner = !isPlaying && !isPremium && remember(adState, aimVisibility) {
        adManager.canDisplayAds(aimVisibility)
    }

    LaunchedEffect(isPlaying, timeLeft) {
        if (isPlaying && timeLeft > 0) {
            delay(1000L)
            timeLeft--
            if (timeLeft == 0) {
                isPlaying = false
                sessionFinished = true
                val totalAttempts = (targetsHit + missCount).coerceAtLeast(1)
                lastAccuracy = (targetsHit.toFloat() / totalAttempts.toFloat()) * 100f
                lastAvgReaction = if (reactionTimes.isNotEmpty()) reactionTimes.average().toInt() else 320

                onSaveSession(
                    AimTrainingSessionStats(
                        id = "train_${System.currentTimeMillis()}",
                        timestamp = System.currentTimeMillis(),
                        durationSeconds = durationSec,
                        difficulty = difficulty,
                        targetSize = targetSize,
                        targetMovement = targetMovement,
                        targetsSpawned = targetsSpawned,
                        targetsHit = targetsHit,
                        accuracyPercent = lastAccuracy,
                        avgReactionTimeMs = lastAvgReaction,
                        bestStreak = bestStreak,
                        missCount = missCount,
                        score = score
                    )
                )
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (shouldShowAimBanner) {
            AdMobAdaptiveBannerSlot(
                visibilityContext = aimVisibility,
                adManager = adManager,
                testTagName = "aim_trainer_ad_banner_slot"
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Polished Aim Trainer", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = NeonRed.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isPlaying) "TIME: ${timeLeft}s" else "READY",
                        color = NeonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            if (!isPlaying && !sessionFinished) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Difficulty Level", color = TextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Easy", "Medium", "Hard", "Expert").forEach { diff ->
                            FilterChip(
                                selected = difficulty == diff,
                                onClick = { difficulty = diff },
                                label = { Text(diff, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f), selectedLabelColor = NeonCyan)
                            )
                        }
                    }

                    Text(text = "Target Size & Movement", color = TextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Small", "Medium", "Large").forEach { sz ->
                            FilterChip(
                                selected = targetSize == sz,
                                onClick = { targetSize = sz },
                                label = { Text(sz, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonGreen.copy(alpha = 0.2f), selectedLabelColor = NeonGreen)
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Stationary", "Moving (Drift)", "Pulsing").forEach { mv ->
                            FilterChip(
                                selected = targetMovement == mv,
                                onClick = { targetMovement = mv },
                                label = { Text(mv, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonPurple.copy(alpha = 0.2f), selectedLabelColor = NeonPurple)
                            )
                        }
                    }

                    Text(text = "Practice Duration", color = TextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 30, 60).forEach { sec ->
                            FilterChip(
                                selected = durationSec == sec,
                                onClick = { durationSec = sec; timeLeft = sec },
                                label = { Text("${sec}s", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f), selectedLabelColor = NeonCyan)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            score = 0
                            targetsHit = 0
                            targetsSpawned = 1
                            missCount = 0
                            currentStreak = 0
                            bestStreak = 0
                            timeLeft = durationSec
                            reactionTimes.clear()
                            sessionFinished = false
                            isPlaying = true

                            val radius = when (targetSize) {
                                "Small" -> 24f
                                "Large" -> 55f
                                else -> 38f
                            }
                            currentTarget = TargetNode(1, Random.nextFloat() * 220f + 40f, Random.nextFloat() * 160f + 40f, radius, System.currentTimeMillis(), targetMovement)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonRed)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Aim Training (${durationSec}s)", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (isPlaying) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Score: $score", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "Streak: $currentStreak (Best: $bestStreak)", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "Misses: $missCount", color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                var arenaWidthPx by remember { mutableStateOf(0f) }
                var arenaHeightPx by remember { mutableStateOf(0f) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceVariant)
                        .onSizeChanged {
                            arenaWidthPx = it.width.toFloat()
                            arenaHeightPx = it.height.toFloat()
                        }
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                val target = currentTarget
                                if (target != null) {
                                    val distance = hypot(offset.x - target.initialX, offset.y - target.initialY)
                                    if (distance <= target.radius * 1.5f) {
                                        targetsHit++
                                        currentStreak++
                                        if (currentStreak > bestStreak) bestStreak = currentStreak
                                        score += when (difficulty) {
                                            "Expert" -> 200
                                            "Hard" -> 150
                                            "Medium" -> 100
                                            else -> 50
                                        }
                                        val reaction = System.currentTimeMillis() - target.spawnTime
                                        reactionTimes.add(reaction)

                                        targetsSpawned++
                                        val radius = when (targetSize) {
                                            "Small" -> 24f
                                            "Large" -> 55f
                                            else -> 38f
                                        }
                                        val margin = radius * 1.6f
                                        val usableW = (arenaWidthPx - margin * 2f).coerceAtLeast(180f)
                                        val usableH = (arenaHeightPx - margin * 2f).coerceAtLeast(140f)
                                        currentTarget = TargetNode(
                                            targetsSpawned,
                                            margin + Random.nextFloat() * usableW,
                                            margin + Random.nextFloat() * usableH,
                                            radius,
                                            System.currentTimeMillis(),
                                            targetMovement
                                        )
                                    } else {
                                        missCount++
                                        currentStreak = 0
                                    }
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        currentTarget?.let { t ->
                            drawCircle(color = NeonRed.copy(alpha = 0.25f), radius = t.radius * 1.5f, center = Offset(t.initialX, t.initialY))
                            drawCircle(color = NeonRed, radius = t.radius, center = Offset(t.initialX, t.initialY))
                            drawCircle(color = Color.White, radius = t.radius * 0.35f, center = Offset(t.initialX, t.initialY))
                        }
                    }
                }
            } else if (sessionFinished) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(44.dp))
                    Text(text = "Training Session Summary", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Final Score:", color = TextSecondary)
                        Text(text = "$score", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Accuracy:", color = TextSecondary)
                        Text(text = "${String.format(java.util.Locale.US, "%.1f", lastAccuracy)}%", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Avg Reaction Time:", color = TextSecondary)
                        Text(text = "${lastAvgReaction} ms", color = NeonPurple, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Best Streak:", color = TextSecondary)
                        Text(text = "$bestStreak hits", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Targets Hit / Missed:", color = TextSecondary)
                        Text(text = "$targetsHit / $missCount", color = TextPrimary, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { sessionFinished = false },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                    ) {
                        Text("Train Again", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    }
}

@Composable
fun AccuracyAnalyticsSection(history: List<AimTrainingSessionStats>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = "Aim Training History & Analytics", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)

            if (history.isEmpty()) {
                Text(text = "No training sessions recorded yet. Play the aim trainer to log statistics.", color = TextSecondary, fontSize = 12.sp)
            } else {
                history.forEach { session ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "${session.difficulty} • ${session.targetSize} (${session.targetMovement})", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "Score: ${session.score}", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Accuracy: ${String.format(java.util.Locale.US, "%.1f", session.accuracyPercent)}%", color = NeonGreen, fontSize = 11.sp)
                                Text(text = "Reaction: ${session.avgReactionTimeMs}ms", color = NeonPurple, fontSize = 11.sp)
                                Text(text = "Streak: ${session.bestStreak}", color = NeonGreen, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HudAdvisorSection() {
    val adviceList = remember { AimIntelligenceRepository.getHudAdviceList() }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(text = "HUD & Control Layout Advisor", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                text = "Optimized ergonomic rules for multi-finger claw layouts and thumb placement.",
                color = TextSecondary,
                fontSize = 12.sp
            )

            adviceList.forEach { advice ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = advice.title, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(text = advice.recommendation, color = TextPrimary, fontSize = 12.sp)
                        Text(text = advice.technicalRationale, color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
    }
}
