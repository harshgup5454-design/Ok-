package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.data.AppPermissionType
import com.example.data.PermissionAuditResult
import com.example.data.PermissionDescriptor
import com.example.data.PermissionManager
import com.example.data.PermissionStatus
import com.example.ui.theme.*

object OnboardingPreferences {
    private const val PREF_NAME = "gameboost_onboarding_prefs"
    private const val KEY_SETUP_COMPLETED = "setup_completed"

    fun isCompleted(context: Context): Boolean {
        return try {
            context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SETUP_COMPLETED, false)
        } catch (_: Exception) {
            false
        }
    }

    fun setCompleted(context: Context, completed: Boolean) {
        try {
            context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SETUP_COMPLETED, completed)
                .apply()
        } catch (_: Exception) {}
    }
}

@Composable
fun PermissionSetupScreen(
    onFinishSetup: () -> Unit,
    isOnboardingMode: Boolean = true,
    onSettingsOpened: ((AppPermissionType) -> Unit)? = null,
    previewSdkInt: Int = Build.VERSION.SDK_INT,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findOwnerActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current

    var auditResult by remember {
        mutableStateOf(PermissionManager.auditPermissions(context, activity, previewSdkInt))
    }
    var pendingExplanation by remember { mutableStateOf<PermissionDescriptor?>(null) }
    var actionFeedback by remember { mutableStateOf<String?>(null) }

    fun refreshAudit() {
        auditResult = PermissionManager.auditPermissions(context, activity, previewSdkInt)
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        refreshAudit()
        actionFeedback = if (granted) {
            "Notifications enabled for foreground sidebar status."
        } else {
            val latest = auditResult.items.firstOrNull { it.type == AppPermissionType.NOTIFICATIONS }
            if (latest?.isPermanentlyDenied == true) {
                "Notifications were denied permanently. Open App Settings to enable them anytime."
            } else {
                "Notifications not granted. You can still use GAMEBOOST or enable them later."
            }
        }
    }

    // Automatically recheck permissions on resume (e.g., when returning from Android Settings)
    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshAudit()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    BackHandler(enabled = !isOnboardingMode) {
        onFinishSetup()
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag(if (isOnboardingMode) "permission_setup_screen" else "permission_center_screen"),
        color = DarkBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (!isOnboardingMode) {
                            IconButton(
                                onClick = onFinishSetup,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("permission_center_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to Settings",
                                    tint = NeonCyan
                                )
                            }
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.gameboost_logo),
                                contentDescription = "GAMEBOOST Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .testTag("onboarding_brand_logo")
                            )
                        }

                        Column {
                            Text(
                                text = if (isOnboardingMode) "FIRST-TIME SETUP" else "PERMISSION CENTER",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                letterSpacing = 1.1.sp
                            )
                            Text(
                                text = if (isOnboardingMode) {
                                    "Configure access for GAMEBOOST 3.0"
                                } else {
                                    "${auditResult.grantedCount} of ${auditResult.totalApplicableCount} applicable permissions granted"
                                },
                                color = TextSecondary,
                                fontSize = 11.5.sp
                            )
                        }
                    }

                    if (isOnboardingMode) {
                        TextButton(
                            onClick = {
                                OnboardingPreferences.setCompleted(context, true)
                                onFinishSetup()
                            },
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("onboarding_skip_button")
                        ) {
                            Text(
                                text = "Skip",
                                color = TextMuted,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("permission_setup_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item(key = "summary_banner") {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            border = BorderStroke(1.dp, DarkSurfaceBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "GAMEBOOST uses standard Android permissions only for enabled features. You can skip optional permissions and still inspect hardware telemetry, profiles, and tools.",
                                color = TextSecondary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (!actionFeedback.isNullOrBlank()) {
                        item(key = "feedback_banner") {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = NeonCyan.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("permission_feedback_banner")
                            ) {
                                Text(
                                    text = actionFeedback.orEmpty(),
                                    color = TextPrimary,
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }

                    items(auditResult.items, key = { it.type.name }) { descriptor ->
                        PermissionItemCard(
                            descriptor = descriptor,
                            onRequestClick = {
                                pendingExplanation = descriptor
                            }
                        )
                    }
                }
            }

            // Bottom action bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isOnboardingMode) {
                    Button(
                        onClick = {
                            OnboardingPreferences.setCompleted(context, true)
                            onFinishSetup()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("onboarding_continue_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                    ) {
                        Text(
                            text = "Continue to GAMEBOOST",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                OutlinedButton(
                    onClick = {
                        refreshAudit()
                        actionFeedback = "Permission statuses updated."
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("permission_recheck_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Recheck Permissions",
                        color = NeonCyan,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    // Explain permission BEFORE opening Android Settings or launching runtime dialog
    pendingExplanation?.let { descriptor ->
        AlertDialog(
            onDismissRequest = { pendingExplanation = null },
            containerColor = DarkSurface,
            modifier = Modifier.testTag("permission_rationale_dialog"),
            title = {
                Text(
                    text = descriptor.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Feature: ${descriptor.featurePurpose}",
                        color = NeonCyan,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = descriptor.rationale,
                        color = TextSecondary,
                        fontSize = 12.5.sp,
                        lineHeight = 18.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = if (descriptor.isPermanentlyDenied) {
                                "Notifications were denied twice or marked 'Don't ask again'. Tap Open App Settings and enable Notifications manually."
                            } else {
                                descriptor.settingsStepHint
                            },
                            color = TextPrimary,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingExplanation = null
                        if (descriptor.type == AppPermissionType.NOTIFICATIONS &&
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            !descriptor.isPermanentlyDenied
                        ) {
                            PermissionManager.markNotificationPermissionRequested(context)
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            onSettingsOpened?.invoke(descriptor.type)
                            val launched = PermissionManager.openPermissionSettings(context, descriptor.type)
                            if (!launched) {
                                actionFeedback = "Unable to open Settings automatically. Please enable ${descriptor.title} in Android Settings."
                            }
                        }
                    },
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("permission_rationale_confirm"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text(
                        text = when {
                            descriptor.type == AppPermissionType.NOTIFICATIONS &&
                                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                !descriptor.isPermanentlyDenied -> "Allow Prompt"
                            descriptor.isPermanentlyDenied -> "Open App Settings"
                            else -> "Open Settings"
                        },
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { pendingExplanation = null },
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("permission_rationale_cancel")
                ) {
                    Text("Not Now", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun PermissionItemCard(
    descriptor: PermissionDescriptor,
    onRequestClick: () -> Unit
) {
    val icon: ImageVector = when (descriptor.type) {
        AppPermissionType.OVERLAY -> Icons.Default.Layers
        AppPermissionType.USAGE_ACCESS -> Icons.Default.QueryStats
        AppPermissionType.NOTIFICATIONS -> Icons.Default.Notifications
        AppPermissionType.WRITE_SETTINGS -> Icons.Default.Tune
        AppPermissionType.DND_ACCESS -> Icons.Default.DoNotDisturbOn
    }

    val statusColor = when (descriptor.status) {
        PermissionStatus.GRANTED -> NeonGreen
        PermissionStatus.NOT_GRANTED -> if (descriptor.isRequiredForOverlay) NeonOrange else NeonCyan
        PermissionStatus.NOT_APPLICABLE -> TextMuted
    }

    val badgeContainer = when (descriptor.status) {
        PermissionStatus.GRANTED -> NeonGreen.copy(alpha = 0.16f)
        PermissionStatus.NOT_GRANTED -> if (descriptor.isRequiredForOverlay) NeonOrange.copy(alpha = 0.16f) else DarkSurfaceVariant
        PermissionStatus.NOT_APPLICABLE -> DarkSurfaceBorder
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("permission_card_${descriptor.type.name.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(
            width = 1.dp,
            color = when (descriptor.status) {
                PermissionStatus.GRANTED -> NeonGreen.copy(alpha = 0.45f)
                PermissionStatus.NOT_GRANTED -> statusColor.copy(alpha = 0.45f)
                PermissionStatus.NOT_APPLICABLE -> DarkSurfaceBorder
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = badgeContainer,
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = descriptor.title,
                            tint = statusColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = descriptor.title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = descriptor.featurePurpose,
                        color = NeonCyan,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeContainer
                ) {
                    Text(
                        text = descriptor.status.label,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("permission_status_${descriptor.type.name.lowercase()}")
                    )
                }
            }

            Text(
                text = descriptor.rationale,
                color = TextSecondary,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )

            if (descriptor.status == PermissionStatus.NOT_GRANTED) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onRequestClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("permission_action_${descriptor.type.name.lowercase()}")
                    ) {
                        Text(
                            text = if (descriptor.isPermanentlyDenied) "Open App Settings" else "Review & Enable",
                            color = Color.Black,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

private tailrec fun Context.findOwnerActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findOwnerActivity()
    else -> null
}
