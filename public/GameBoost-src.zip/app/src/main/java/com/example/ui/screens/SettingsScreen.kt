package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.GamingOverlayService
import com.example.ui.theme.*

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ads.AdManager
import com.example.ads.GoogleAdMobManager
import com.example.data.GameSpaceManager
import com.example.data.OverlayConfig
import com.example.data.PermissionManager
import com.example.data.PermissionStatus

@Composable
fun SettingsScreen(
    overlayConfig: OverlayConfig = OverlayConfig(),
    adManager: AdManager = GoogleAdMobManager,
    onUpdateOverlayConfig: ((OverlayConfig) -> OverlayConfig) -> Unit = {},
    onNavigateToPremium: () -> Unit = {},
    onOpenPermissionCenter: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current
    val adState by adManager.adState.collectAsState()
    val entitlement by com.example.data.MembershipManager.entitlement.collectAsState()
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }
    var privacyActionFeedback by remember { mutableStateOf<String?>(null) }
    var themeGateFeedback by remember { mutableStateOf<String?>(null) }
    var overlayActionFeedback by remember { mutableStateOf<String?>(null) }

    fun readOverlayPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true

    fun readNotificationPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true

    var canDrawOverlay by remember { mutableStateOf(readOverlayPerm()) }
    var hasNotificationPerm by remember { mutableStateOf(readNotificationPerm()) }
    var hasUsageAccess by remember { mutableStateOf(GameSpaceManager.hasUsageStatsPermission(context)) }
    var permissionAudit by remember { mutableStateOf(PermissionManager.auditPermissions(context, activity)) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPerm = granted
        permissionAudit = PermissionManager.auditPermissions(context, activity)
    }

    val serviceRunningState by GamingOverlayService.isServiceRunning.collectAsState()
    val lastOverlayError by GamingOverlayService.lastOverlayError.collectAsState()
    val overlayLogs by GamingOverlayService.diagnosticLogs.collectAsState()
    var showLogsExpanded by remember { mutableStateOf(false) }

    // Re-check overlay, notification & usage permissions every time user returns from Android Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                canDrawOverlay = readOverlayPerm()
                hasNotificationPerm = readNotificationPerm()
                hasUsageAccess = GameSpaceManager.hasUsageStatsPermission(context)
                permissionAudit = PermissionManager.auditPermissions(context, activity)
                if (canDrawOverlay) {
                    overlayActionFeedback = null
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("settings_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Settings & Sidebar",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Overlay permissions, HUD layout & privacy",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                OutlinedButton(
                    onClick = onNavigateToPremium,
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("settings_pro_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = NeonPurple
                    )
                ) {
                    Icon(Icons.Default.Stars, contentDescription = "GAMEBOOST Pro", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (entitlement.isPremium) "PRO Active" else "Upgrade Pro",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Permission Center Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_permission_center_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                            Column {
                                Text(
                                    text = "Permission Center",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.5.sp
                                )
                                Text(
                                    text = "${permissionAudit.grantedCount}/${permissionAudit.totalApplicableCount} applicable permissions granted",
                                    color = if (permissionAudit.hasOverlayPermission) NeonGreen else NeonOrange,
                                    fontSize = 11.5.sp
                                )
                            }
                        }

                        Button(
                            onClick = onOpenPermissionCenter,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("settings_permission_center_button")
                        ) {
                            Text(
                                text = "Manage",
                                color = androidx.compose.ui.graphics.Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        permissionAudit.items.take(3).forEach { item ->
                            val chipColor = when (item.status) {
                                PermissionStatus.GRANTED -> NeonGreen
                                PermissionStatus.NOT_GRANTED -> NeonOrange
                                PermissionStatus.NOT_APPLICABLE -> TextMuted
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = chipColor.copy(alpha = 0.14f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "${item.title.substringBefore(" ")}: ${item.status.label}",
                                    color = chipColor,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Global Gaming Sidebar Service Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Layers, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                            Column {
                                Text(text = "Display Over Other Apps", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                                Text(
                                    text = if (canDrawOverlay) "Granted" else "Required for floating game sidebar",
                                    color = if (canDrawOverlay) NeonGreen else NeonOrange,
                                    fontSize = 11.5.sp
                                )
                            }
                        }

                        if (!canDrawOverlay) {
                            Button(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        val opened = PermissionManager.openPermissionSettings(
                                            context,
                                            com.example.data.AppPermissionType.OVERLAY
                                        )
                                        if (!opened) {
                                            overlayActionFeedback = "Open Android Settings > Apps > Display over other apps."
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_overlay_grant_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                            ) {
                                Text(text = "Grant", color = androidx.compose.ui.graphics.Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPerm) {
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Foreground Notification", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Required on Android 13+ for active sidebar status.", color = TextSecondary, fontSize = 11.sp)
                            }
                            TextButton(
                                onClick = {
                                    PermissionManager.markNotificationPermissionRequested(context)
                                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text("Allow", color = NeonCyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (canDrawOverlay) {
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "Floating Gaming Sidebar", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = if (serviceRunningState) "Running over games • Tap or slide edge handle" else "Shows edge handle over Free Fire MAX & other games",
                                    color = if (serviceRunningState) NeonGreen else TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = serviceRunningState,
                                modifier = Modifier.testTag("settings_overlay_service_switch"),
                                onCheckedChange = { enabled ->
                                    if (enabled) {
                                        val res = GamingOverlayService.startOverlay(context)
                                        overlayActionFeedback = if (res.started) null else res.reason
                                        if (!res.started && !readOverlayPerm() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            canDrawOverlay = false
                                        }
                                    } else {
                                        GamingOverlayService.stopOverlay(context)
                                        GamingOverlayService.clearLastOverlayError()
                                        overlayActionFeedback = null
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan, checkedTrackColor = DarkSurfaceVariant)
                            )
                        }
                    }

                    val visibleError = overlayActionFeedback ?: lastOverlayError
                    if (!visibleError.isNullOrBlank()) {
                        Text(
                            text = visibleError,
                            color = NeonOrange,
                            fontSize = 11.sp,
                            modifier = Modifier.testTag("settings_overlay_error_text")
                        )
                    }
                }
            }
        }

        // Optional Foreground Game Detection (Usage Access)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Optional Foreground Game Detection", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = if (hasUsageAccess) "Usage Access Granted (Opt-in)" else "Requires Usage Access permission in Android Settings",
                                color = if (hasUsageAccess) NeonGreen else TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        if (!hasUsageAccess) {
                            TextButton(onClick = {
                                val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                try { context.startActivity(intent) } catch (_: Exception) {}
                            }) {
                                Text("Authorize", color = NeonCyan, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Switch(
                                checked = overlayConfig.autoDetectForegroundGame,
                                onCheckedChange = { enabled ->
                                    onUpdateOverlayConfig { it.copy(autoDetectForegroundGame = enabled) }
                                }
                            )
                        }
                    }
                    Text(
                        text = "Privacy Notice: GAMEBOOST never uploads or shares app usage history. Launching games directly from Gaming Space works with zero extra permissions.",
                        color = TextMuted,
                        fontSize = 10.5.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // Overlay Diagnostic Logs & OEM Restrictions Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                            Text(text = "Overlay Diagnostics & OEM Notes", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        TextButton(onClick = { showLogsExpanded = !showLogsExpanded }) {
                            Text(if (showLogsExpanded) "Hide Logs" else "View Logs (${overlayLogs.size})", color = NeonCyan, fontSize = 11.sp)
                        }
                    }

                    Text(
                        text = "Android & OEM Notes: On Xiaomi/POCO/Redmi (MIUI/HyperOS), allow 'Display pop-up windows while running in the background' in App Info. Some full-screen games or OEM Game Turbo modes restrict third-party overlays without root.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    if (showLogsExpanded) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceVariant
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (overlayLogs.isEmpty()) {
                                    Text("No overlay events recorded yet. Toggle the service above to trace WindowManager status.", color = TextMuted, fontSize = 10.5.sp)
                                } else {
                                    overlayLogs.take(12).forEach { entry ->
                                        Text(entry, color = TextPrimary, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Persisted Trigger & Overlay Appearance Customization Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(text = "Overlay Trigger & HUD Customization", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Trigger Vertical Position", color = TextSecondary, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Top", "Center", "Bottom").forEach { pos ->
                                FilterChip(
                                    selected = overlayConfig.triggerPosition == pos,
                                    onClick = { onUpdateOverlayConfig { it.copy(triggerPosition = pos) } },
                                    label = { Text(pos) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonCyan
                                    )
                                )
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Trigger Touch Width / Sensitivity", color = TextSecondary, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(16 to "Slim (16dp)", 24 to "Standard (24dp)", 32 to "Wide (32dp)").forEach { (width, label) ->
                                FilterChip(
                                    selected = overlayConfig.triggerWidthDp == width,
                                    onClick = { onUpdateOverlayConfig { it.copy(triggerWidthDp = width) } },
                                    label = { Text(label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonCyan
                                    )
                                )
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (entitlement.allowOverlayTheming) {
                                "Overlay Accent Theme (All Pro Themes Unlocked)"
                            } else {
                                "Overlay Accent Theme (Cyan Free • Purple/Green/OLED Pro)"
                            },
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Cyan", "Purple", "Green", "OLED").forEach { accent ->
                                val isProTheme = accent != "Cyan"
                                val isUnlocked = !isProTheme || entitlement.allowOverlayTheming
                                FilterChip(
                                    selected = overlayConfig.accentTheme == accent,
                                    onClick = {
                                        if (isUnlocked) {
                                            themeGateFeedback = null
                                            onUpdateOverlayConfig { it.copy(accentTheme = accent) }
                                        } else {
                                            themeGateFeedback = "$accent overlay theme requires GAMEBOOST Pro. Cyan remains free."
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = if (isProTheme && !entitlement.allowOverlayTheming) "$accent PRO" else accent,
                                            fontSize = 10.5.sp
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonCyan
                                    )
                                )
                            }
                        }
                        if (!themeGateFeedback.isNullOrBlank()) {
                            Text(
                                text = themeGateFeedback.orEmpty(),
                                color = NeonPurple,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Default Panel Opacity", color = TextSecondary, fontSize = 12.sp)
                            Text(text = "${(overlayConfig.panelOpacity * 100).toInt()}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Slider(
                            value = overlayConfig.panelOpacity,
                            onValueChange = { alpha -> onUpdateOverlayConfig { it.copy(panelOpacity = alpha) } },
                            valueRange = 0.5f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Open Overlay in Compact HUD Mode", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Opens as a compact pill showing timer, temp, and latency.", color = TextSecondary, fontSize = 10.5.sp)
                        }
                        Switch(
                            checked = overlayConfig.defaultCompactMode,
                            onCheckedChange = { compact -> onUpdateOverlayConfig { it.copy(defaultCompactMode = compact) } }
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Long Session Break Reminder", color = TextSecondary, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(30, 45, 60).forEach { mins ->
                                FilterChip(
                                    selected = overlayConfig.longSessionReminderMinutes == mins,
                                    onClick = { onUpdateOverlayConfig { it.copy(longSessionReminderMinutes = mins) } },
                                    label = { Text("${mins} min") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonGreen.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonGreen
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Privacy, Consent & AdMob Transparency Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                        Text(
                            text = "Privacy & Ad Consent",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Text(
                        text = if (adManager.isAdFreeEntitled()) {
                            "Status: Ad-Free Pro entitlement active — ordinary ads are hidden."
                        } else {
                            "Consent: ${adState.consentStatusMessage}\nSDK: ${adState.sdkStatusMessage}"
                        },
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showPrivacyPolicyDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("settings_privacy_policy_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan)
                        ) {
                            Text("Privacy Policy", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }

                        OutlinedButton(
                            onClick = {
                                val activity = context.findActivity()
                                if (activity != null && adState.isPrivacyOptionsRequired) {
                                    adManager.showPrivacyOptionsForm(activity) { err ->
                                        privacyActionFeedback = err ?: "Consent preferences updated."
                                    }
                                } else {
                                    privacyActionFeedback = if (adState.isPrivacyOptionsRequired) {
                                        "Open from main activity to update UMP consent."
                                    } else {
                                        "UMP privacy options form is only required in regulated regions (e.g., EEA/UK)."
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("settings_ad_privacy_options_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonGreen)
                        ) {
                            Text("Ad Privacy Options", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (!privacyActionFeedback.isNullOrBlank()) {
                        Text(
                            text = privacyActionFeedback.orEmpty(),
                            color = TextMuted,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }
        }

        // Developer AdMob Diagnostics & Live Status Section
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_admob_diagnostics_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.BugReport, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(20.dp))
                            Text(
                                text = "AdMob Diagnostics & Status",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (adState.isTestMode) NeonGreen.copy(alpha = 0.15f) else DarkSurfaceBorder
                        ) {
                            Text(
                                text = if (adState.isTestMode) "TEST MODE" else "PRODUCTION",
                                color = if (adState.isTestMode) NeonGreen else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Diagnostic Item 1: SDK Initialization & Adapter Readiness
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Mobile Ads SDK:", color = TextSecondary, fontSize = 12.sp)
                        val sdkLabel = if (adState.isSdkInitialized) {
                            if (adState.totalAdaptersCount > 0) {
                                "Initialized (${adState.readyAdaptersCount}/${adState.totalAdaptersCount} ready)"
                            } else {
                                "Initialized"
                            }
                        } else {
                            "Standby / Initializing"
                        }
                        Text(
                            text = sdkLabel,
                            color = if (adState.isSdkInitialized) NeonGreen else NeonOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Diagnostic Item 2: Consent Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("UMP Can Request Ads:", color = TextSecondary, fontSize = 12.sp)
                        Text(
                            text = if (adState.canRequestAds) "Granted / Ready (true)" else "Pending / Restricted (false)",
                            color = if (adState.canRequestAds) NeonGreen else NeonOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Diagnostic Item 3: Ad Eligibility
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ad Eligibility:", color = TextSecondary, fontSize = 12.sp)
                        Text(
                            text = when {
                                adManager.isAdFreeEntitled() -> "Ad-Free (Pro User)"
                                !adState.isNetworkAvailable -> "Suppressed (Offline)"
                                !adState.canRequestAds -> "Suppressed (No Consent)"
                                else -> "Eligible (Idle Browsing)"
                            },
                            color = if (!adManager.isAdFreeEntitled() && adState.canRequestAds && adState.isNetworkAvailable) NeonGreen else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Diagnostic Item 4: Banner & Native Load Status
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Placements Live Status:", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = "Home: ${adState.homeBannerStatus.name} | Native: ${adState.nativeSponsoredStatus.name}",
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                        }
                        val lastLoc = adState.lastBannerLocation
                        if (lastLoc != null) {
                            Text(
                                text = "Latest Banner (${lastLoc.name}): ${adState.lastBannerStatus.name} | Reports Banner: ${adState.reportsBannerStatus.name}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Diagnostic Item 5: Request, Loaded, No-Fill & Failed Counters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ad Outcome Counters:", color = TextSecondary, fontSize = 12.sp)
                        Text(
                            text = "Req: ${adState.totalRequestsCount} | Loaded: ${adState.totalLoadedCount} | NoFill: ${adState.noFillCount} | Err: ${adState.failedCount}",
                            color = NeonCyan,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Diagnostic Item 6: Last Error Code & Message
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        val errHeading = if (adState.lastErrorCode != null) {
                            "Last Load Outcome (Error Code ${adState.lastErrorCode}):"
                        } else {
                            "Last Load Outcome / Error:"
                        }
                        Text(errHeading, color = TextSecondary, fontSize = 11.sp)
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = DarkBackground
                        ) {
                            Text(
                                text = adState.lastAdError ?: "No errors recorded.",
                                color = if (adState.lastAdError != null) NeonOrange else TextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    // Action: Retry Consent & SDK Flow
                    Button(
                        onClick = {
                            val activity = context.findActivity()
                            if (activity != null) {
                                adManager.retryConsentAndSdkFlow(activity)
                                privacyActionFeedback = "Re-requesting UMP consent and initializing Mobile Ads..."
                            } else {
                                privacyActionFeedback = "Activity unavailable for consent retry."
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("settings_retry_admob_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = androidx.compose.ui.graphics.Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Retry Consent & SDK Initialization",
                            color = androidx.compose.ui.graphics.Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    if (com.example.BuildConfig.DEBUG) {
                        // Active AdMob IDs & dev toggle (debug builds only)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Active AdMob Configuration:",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "• App ID: ${com.example.ads.AdMobConfig.currentAppId}",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "• Banner ID: ${com.example.ads.AdMobConfig.currentBannerAdUnitId}",
                                color = NeonCyan,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "• Native Advanced ID: ${com.example.ads.AdMobConfig.currentNativeAdUnitId}",
                                color = NeonGreen,
                                fontSize = 10.sp
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val isTest = adManager.toggleAdMobTestMode()
                                privacyActionFeedback = if (isTest) "Switched to Official Google Sample Test Ad Units" else "Switched to Production AdMob IDs (pub-9880038173911569)"
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("settings_toggle_test_mode_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = if (adState.isTestMode) NeonGreen else NeonCyan)
                        ) {
                            Text(
                                text = if (adState.isTestMode) "Switch to Production IDs" else "Use Development Test IDs",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // About & Integrity Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Engineering Transparency & Validation",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )

                    SettingRow(
                        icon = Icons.Default.Info,
                        title = "App Version",
                        subtitle = "${com.example.BuildConfig.VERSION_NAME} (Build ${com.example.BuildConfig.VERSION_CODE})"
                    )

                    SettingRow(
                        icon = Icons.Default.Security,
                        title = "Zero Root & Zero Game Tampering",
                        subtitle = "Runs strictly in standard Android user space. Never injects code or modifies game OBB/data files."
                    )

                    SettingRow(
                        icon = Icons.Default.Speed,
                        title = "Real Device Measurement Integrity",
                        subtitle = "Displays genuine PowerManager thermal status and TCP latency. We never show fake FPS numbers."
                    )
                }
            }
        }
    }

    if (showPrivacyPolicyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicyDialog = false },
            containerColor = DarkSurface,
            title = {
                Text(
                    text = "GAMEBOOST Privacy Policy",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = "• Local Telemetry Only: CPU, RAM, battery, thermal status, and saved game profiles remain stored locally in Room on your device.\n" +
                        "• Optional Usage Access: Foreground app checks occur strictly on-device when opted in and are never uploaded.\n" +
                        "• Advertising & Consent: Non-intrusive banners on idle browsing screens use the Google Mobile Ads SDK and User Messaging Platform (UMP) where required.\n" +
                        "• Zero Gameplay Interference: Ads never appear during active gaming sessions, benchmarks, scans, tools, or inside the floating overlay.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showPrivacyPolicyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Close", color = androidx.compose.ui.graphics.Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}
