package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun DashboardProtectionBanner(
    protectionStatus: GamingProtectionStatus,
    onOpenSmartGaming: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val accentColor = when (protectionStatus.overallSeverity) {
        ProtectionSeverity.CRITICAL -> NeonRed
        ProtectionSeverity.WARNING -> NeonOrange
        ProtectionSeverity.ADVISORY -> NeonCyan
        ProtectionSeverity.SAFE -> NeonGreen
    }
    val readinessLabel = when (protectionStatus.overallSeverity) {
        ProtectionSeverity.CRITICAL -> "THERMAL ALERT"
        ProtectionSeverity.WARNING -> "CAUTION"
        ProtectionSeverity.ADVISORY -> "ADVISORY"
        ProtectionSeverity.SAFE -> "READY"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_protection_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (protectionStatus.alerts.isNotEmpty()) expanded = !expanded
                        else onOpenSmartGaming()
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (protectionStatus.overallSeverity == ProtectionSeverity.SAFE) {
                            Icons.Default.VerifiedUser
                        } else {
                            Icons.Default.HealthAndSafety
                        },
                        contentDescription = protectionStatus.headline,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = protectionStatus.headline,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Battery: ${protectionStatus.batteryHealthLabel}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accentColor.copy(alpha = 0.16f)
                ) {
                    Text(
                        text = readinessLabel,
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            AnimatedVisibility(visible = expanded && protectionStatus.alerts.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    HorizontalDivider(color = DarkSurfaceBorder)
                    protectionStatus.alerts.forEach { alert ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceVariant
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(alert.title, color = accentColor, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                Text(alert.recommendation, color = TextSecondary, fontSize = 10.5.sp, lineHeight = 14.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VisualGaugeCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    progress: Float
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Text(
                text = value,
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = accentColor,
                trackColor = DarkSurfaceVariant
            )

            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun DashboardQuickLaunchAndRecentCard(
    installedGames: List<GameProfile>,
    latestSession: BenchmarkSessionReport?,
    onLaunchGame: (GameProfile) -> Unit,
    onNavigateToGamingSpace: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val featuredGame = remember(installedGames) {
        installedGames.firstOrNull { it.isInLibrary && it.isInstalled && it.isFavorite }
            ?: installedGames.firstOrNull { it.isInLibrary && it.isInstalled }
            ?: installedGames.firstOrNull { it.isInLibrary }
    }

    if (featuredGame == null && latestSession == null) return

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (featuredGame != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = featuredGame.name,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${featuredGame.performanceMode.displayName} • ${featuredGame.fpsLock} FPS",
                            color = NeonCyan,
                            fontSize = 10.5.sp
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = onNavigateToGamingSpace,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("All", color = TextSecondary, fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onLaunchGame(featuredGame) },
                            enabled = featuredGame.isInstalled,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                            modifier = Modifier
                                .heightIn(min = 40.dp)
                                .testTag("dashboard_quick_launch_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Launch ${featuredGame.name}", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (featuredGame.isInstalled) "Launch" else "Missing",
                                color = Color.Black,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            if (latestSession != null) {
                HorizontalDivider(color = DarkSurfaceBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToReports() }
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val mins = latestSession.durationSeconds / 60
                    val secs = latestSession.durationSeconds % 60
                    val tempLabel = if (latestSession.peakTempC > 0f) {
                        String.format(Locale.US, "%.1f°C", latestSession.peakTempC)
                    } else {
                        "Temp N/A"
                    }
                    Text(
                        text = String.format(Locale.US, "Last: %s • %dm %02ds • %s", latestSession.gameTitle, mins, secs, tempLabel),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.ChevronRight, contentDescription = "Reports", tint = NeonCyan, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
