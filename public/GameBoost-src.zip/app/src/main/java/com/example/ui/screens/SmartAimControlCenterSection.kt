package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun SmartAimControlCenterSection(
    controlState: SmartAimControlState,
    gyroState: GyroscopeTelemetry,
    deviceSpecs: AimDeviceSpecs?,
    savedProfiles: List<SensitivityProfile>,
    onMasterSwitchChanged: (Boolean) -> Unit,
    onModeSelected: (AimOptimizationMode) -> Unit,
    onGameSelected: (String) -> Unit,
    onApplyPreset: (String, AimOptimizationMode) -> Unit,
    onCalibrateGyro: () -> Unit,
    onSelectProfile: (SensitivityProfile) -> Unit,
    onExportProfiles: () -> Unit,
    onImportProfiles: () -> Unit
) {
    val context = LocalContext.current
    var isDeviceSpecsExpanded by remember { mutableStateOf(false) }
    var isManualGuideExpanded by remember { mutableStateOf(false) }

    val supportedGames = listOf("Free Fire MAX", "BGMI / PUBG Mobile", "Call of Duty: Mobile")

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Master Control Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (controlState.isMasterEnabled) NeonCyan.copy(alpha = 0.5f) else DarkSurfaceBorder
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (controlState.isMasterEnabled) NeonCyan.copy(alpha = 0.2f) else DarkSurfaceVariant,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.GpsFixed,
                                    contentDescription = null,
                                    tint = if (controlState.isMasterEnabled) NeonCyan else TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "SMART AIM & ROTATION OPTIMIZER",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (controlState.isMasterEnabled) "Optimizer Active • Real-time Assistance" else "Optimizer Disabled",
                                color = if (controlState.isMasterEnabled) NeonGreen else TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = controlState.isMasterEnabled,
                        onCheckedChange = onMasterSwitchChanged,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = DarkSurfaceVariant
                        )
                    )
                }

                HorizontalDivider(color = DarkSurfaceBorder)

                // Mode Selector Strip
                Text(
                    text = "SELECT AIMING STRATEGY",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AimOptimizationMode.values().forEach { mode ->
                        val isSelected = controlState.activeMode == mode
                        val accentColor = when (mode) {
                            AimOptimizationMode.ACCURACY -> NeonCyan
                            AimOptimizationMode.FAST_ROTATION -> NeonPurple
                            AimOptimizationMode.BALANCED -> NeonGreen
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) accentColor.copy(alpha = 0.18f) else DarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) accentColor else Color.Transparent
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable(enabled = controlState.isMasterEnabled) {
                                    onModeSelected(mode)
                                    onApplyPreset(controlState.selectedGame, mode)
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = when (mode) {
                                        AimOptimizationMode.ACCURACY -> Icons.Default.FilterCenterFocus
                                        AimOptimizationMode.FAST_ROTATION -> Icons.Default.RotateRight
                                        AimOptimizationMode.BALANCED -> Icons.Default.Balance
                                    },
                                    contentDescription = null,
                                    tint = if (isSelected) accentColor else TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = mode.displayName,
                                    color = if (isSelected) TextPrimary else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.5.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (isSelected) "ON" else "OFF",
                                    color = if (isSelected) accentColor else TextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active Game & Target Preset Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TARGET GAME INTEGRATION",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = NeonCyan.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = controlState.selectedGame,
                            color = NeonCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    supportedGames.forEach { game ->
                        val isSelected = controlState.selectedGame == game
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                onGameSelected(game)
                                onApplyPreset(game, controlState.activeMode)
                            },
                            label = { Text(game.take(12), fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                selectedLabelColor = NeonCyan
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // In-Game Setting Notice
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Text(
                                text = "In-Game Configuration Reminder",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                        Text(
                            text = "To apply ${controlState.activeMode.displayName} inside ${controlState.selectedGame}, open the in-game Settings > Sensitivity and manually match the values provided below. GAMEBOOST does not modify third-party game code or memory.",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Hardware Gyroscope & Touch Sensor Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ScreenRotation, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                        Text(
                            text = "GYROSCOPE & SENSOR STATUS",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    if (gyroState.isAvailable) {
                        Button(
                            onClick = onCalibrateGyro,
                            enabled = !gyroState.isCalibrating,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(
                                text = if (gyroState.isCalibrating) "Calibrating..." else "Calibrate",
                                color = NeonGreen,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (gyroState.isAvailable) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SensorStatBox(
                            label = "X Axis",
                            value = String.format(Locale.US, "%.2f", gyroState.xRadPerSec),
                            unit = "rad/s",
                            modifier = Modifier.weight(1f)
                        )
                        SensorStatBox(
                            label = "Y Axis",
                            value = String.format(Locale.US, "%.2f", gyroState.yRadPerSec),
                            unit = "rad/s",
                            modifier = Modifier.weight(1f)
                        )
                        SensorStatBox(
                            label = "Z Axis",
                            value = String.format(Locale.US, "%.2f", gyroState.zRadPerSec),
                            unit = "rad/s",
                            modifier = Modifier.weight(1f)
                        )
                        SensorStatBox(
                            label = "Stability",
                            value = "${gyroState.stabilityIndex.toInt()}%",
                            unit = if (gyroState.calibrated) "Calibrated" else "Live",
                            modifier = Modifier.weight(1.2f)
                        )
                    }
                } else {
                    Text(
                        text = "Hardware gyroscope not detected on this hardware profile. Standard thumb drag sensitivity will be utilized.",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                // Device Specs Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isDeviceSpecsExpanded = !isDeviceSpecsExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "View Screen Resolution, Touch & Refresh Rate",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Icon(
                        imageVector = if (isDeviceSpecsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                AnimatedVisibility(visible = isDeviceSpecsExpanded) {
                    deviceSpecs?.let { specs ->
                        Column(
                            modifier = Modifier.padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            SpecRow("Device:", specs.deviceModel)
                            SpecRow("Resolution:", specs.screenResolutionPx)
                            SpecRow("Display Refresh Rate:", "${specs.refreshRateHz.toInt()} Hz (Panel Speed)")
                            SpecRow("Touch Multi-touch Points:", "${specs.touchMaxPointers} fingers")
                            SpecRow("Screen DPI Tier:", "${specs.screenDpi} DPI")
                            SpecRow("Gyro Sensor:", specs.gyroSensorName)
                            Text(
                                text = "Notice: Display panel refresh rate (Hz) measures screen scanning frequency, not in-game render FPS.",
                                color = TextMuted,
                                fontSize = 9.5.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Profile Management & Quick Restore Strip
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SAVED PROFILES & RESTORATION",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = onExportProfiles,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text("Export", fontSize = 10.sp, color = NeonCyan)
                        }
                        OutlinedButton(
                            onClick = onImportProfiles,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text("Import", fontSize = 10.sp, color = NeonGreen)
                        }
                    }
                }

                if (savedProfiles.isEmpty()) {
                    Text(
                        text = "No saved sensitivity profiles yet. Use the presets above or calculate below.",
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                } else {
                    savedProfiles.take(4).forEach { profile ->
                        val isCurrent = controlState.activeProfileId == profile.id || controlState.activeProfileName == profile.profileName
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isCurrent) DarkSurfaceVariant else DarkSurfaceVariant.copy(alpha = 0.5f),
                            border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.dp, NeonCyan) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectProfile(profile) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = profile.profileName,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "${profile.gameName} • General: ${profile.general} • RedDot: ${profile.redDot}",
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                                if (isCurrent) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = NeonCyan.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "ACTIVE",
                                            color = NeonCyan,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                } else {
                                    Text("Restore", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SensorStatBox(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSurfaceVariant,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = label, color = TextMuted, fontSize = 9.5.sp)
            Text(text = value, color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(text = unit, color = TextSecondary, fontSize = 8.5.sp)
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 11.sp)
        Text(text = value, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    }
}
