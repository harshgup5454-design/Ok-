package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.ads.AdManager
import com.example.ads.AdScreenLocation
import com.example.ads.AdVisibilityContext
import com.example.ads.GoogleAdMobManager
import com.example.data.BenchmarkSessionReport
import com.example.data.DeviceStats
import com.example.data.GamingProtectionStatus
import com.example.data.MembershipManager
import com.example.data.ProtectionSeverity
import com.example.data.SessionAnalyticsAggregator
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ReportsScreen(
    stats: DeviceStats,
    isBenchmarking: Boolean,
    benchmarkSeconds: Int,
    benchmarkSessions: List<BenchmarkSessionReport>,
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    isScanning: Boolean = false,
    protectionStatus: GamingProtectionStatus = GamingProtectionStatus(),
    adManager: AdManager = GoogleAdMobManager,
    onStartBenchmark: (String, String, String, String, String) -> Unit,
    onStopBenchmark: (Float?, Float?) -> Unit,
    onNavigateToPremium: () -> Unit = {}
) {
    var sessionLabel by remember { mutableStateOf("") }
    var selectedGame by remember { mutableStateOf("BGMI / PUBG Mobile") }
    var graphicsSettings by remember { mutableStateOf("Smooth + Ultra (Shadows OFF)") }
    var selectedFpsSource by remember { mutableStateOf("None (FPS Unavailable)") }
    var userNotes by remember { mutableStateOf("") }

    var showStopDialog by remember { mutableStateOf(false) }
    var inputAvgFpsText by remember { mutableStateOf("") }
    var inputMinFpsText by remember { mutableStateOf("") }

    val context = LocalContext.current
    val entitlement by MembershipManager.entitlement.collectAsState()
    val effectiveIsPremium = isPremium || entitlement.isPremium
    val maxHistoryCount = if (effectiveIsPremium) 50 else 10
    val visibleSessions = remember(benchmarkSessions, maxHistoryCount) {
        benchmarkSessions.take(maxHistoryCount)
    }
    var exportedFeedback by remember { mutableStateOf<String?>(null) }

    val sessionSummary = remember(benchmarkSessions) {
        SessionAnalyticsAggregator.summarize(benchmarkSessions)
    }

    val nativeAdVisibility = AdVisibilityContext(
        location = AdScreenLocation.REPORTS_NATIVE_SPONSORED,
        isGamingSessionActive = isBenchmarking || isAutopilotActive,
        isAutopilotSessionActive = isAutopilotActive,
        isBenchmarking = isBenchmarking,
        isScanning = isScanning,
        hasWarningOrErrorDialog = showStopDialog,
        thermalSeverity = protectionStatus.overallSeverity
    )
    val reportsBannerVisibility = nativeAdVisibility.copy(location = AdScreenLocation.REPORTS_BANNER)
    val shouldShowSponsoredCard = !effectiveIsPremium && adManager.canDisplayAds(nativeAdVisibility)
    val shouldShowReportsBanner = !effectiveIsPremium && adManager.canDisplayAds(reportsBannerVisibility)

    val formattedBenchmarkTime = remember(benchmarkSeconds) {
        val mins = benchmarkSeconds / 60
        val secs = benchmarkSeconds % 60
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("reports_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "FPS Validation & Telemetry Reports",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Transparent performance benchmarking. Compares thermal rise, battery drain, and genuine observed FPS under controlled test conditions.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Live Benchmark Session Recorder Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timeline,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "Telemetry Session Recorder",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        if (isBenchmarking) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = NeonRed.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "RECORDING $formattedBenchmarkTime",
                                    color = NeonRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    if (!isBenchmarking) {
                        OutlinedTextField(
                            value = sessionLabel,
                            onValueChange = { sessionLabel = it },
                            label = { Text("Session Description", fontSize = 12.sp) },
                            placeholder = { Text("e.g. Test Run A: Playing while charging", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkSurfaceBorder
                            )
                        )

                        OutlinedTextField(
                            value = graphicsSettings,
                            onValueChange = { graphicsSettings = it },
                            label = { Text("In-Game Graphics Settings", fontSize = 12.sp) },
                            placeholder = { Text("e.g. Smooth + High Cap + Shadows OFF", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkSurfaceBorder
                            )
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = "FPS Measurement Source", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(
                                    "None (FPS Unavailable)" to "Standard / No OEM tool",
                                    "OEM Game Turbo / Space" to "OEM Tool Active",
                                    "ADB gfxinfo / Perfetto" to "ADB Profiler"
                                ).forEach { (sourceKey, label) ->
                                    FilterChip(
                                        selected = selectedFpsSource == sourceKey,
                                        onClick = { selectedFpsSource = sourceKey },
                                        label = { Text(label, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                            selectedLabelColor = NeonCyan
                                        )
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = {
                                onStartBenchmark(
                                    sessionLabel.ifBlank { "Test Session" },
                                    selectedGame,
                                    graphicsSettings,
                                    selectedFpsSource,
                                    userNotes
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reports_start_benchmark_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Start Live Benchmark Session", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Sampling hardware telemetry (battery temp, PowerManager status, RAM, TCP latency)...",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )

                            Button(
                                onClick = { showStopDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reports_stop_benchmark_button")
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Finish & Save Benchmark Report", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Daily/Weekly Session Analytics Summary
        item {
            SessionAnalyticsOverviewCard(summary = sessionSummary)
        }

        // Temperature Curve & 2-Session Comparison (up to 10 Free / 50 Pro)
        if (visibleSessions.isNotEmpty()) {
            item {
                SessionComparisonAndChartCard(
                    sessions = visibleSessions,
                    maxSessionsCount = maxHistoryCount
                )
            }
        }

        // Pro Advanced Session Insights & Structured Export Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reports_pro_insights_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Extended History & Pro Report Export",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (effectiveIsPremium) NeonPurple.copy(alpha = 0.2f) else DarkSurfaceVariant
                        ) {
                            Text(
                                text = if (effectiveIsPremium) "PRO (UP TO 50)" else "FREE (LAST 10)",
                                color = if (effectiveIsPremium) NeonPurple else TextSecondary,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (effectiveIsPremium) {
                        val stableCount = visibleSessions.count { !it.throttlingObserved }
                        val stabilityPct = if (visibleSessions.isEmpty()) 100 else ((stableCount * 100f) / visibleSessions.size).toInt()
                        val avgRamFree = if (visibleSessions.isEmpty()) stats.availableMemoryGb else visibleSessions.map { it.avgAvailRamGb }.average().toFloat()
                        Text(
                            text = "Showing ${visibleSessions.size} of ${benchmarkSessions.size} saved runs • Thermal Stability Rate: $stabilityPct% • Avg Free RAM: ${String.format(Locale.US, "%.2f", avgRamFree)} GB",
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )

                        Button(
                            onClick = {
                                val reportText = buildProTelemetryReportSummary(stats, visibleSessions, stabilityPct)
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                clipboard?.setPrimaryClip(ClipData.newPlainText("GAMEBOOST Telemetry Report", reportText))
                                exportedFeedback = "Copied ${visibleSessions.size}-session telemetry summary to clipboard."
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("reports_pro_export_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy Pro Session Report Summary", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        if (!exportedFeedback.isNullOrBlank()) {
                            Text(text = exportedFeedback.orEmpty(), color = NeonGreen, fontSize = 10.5.sp)
                        }
                    } else {
                        Text(
                            text = "Free shows last 10 runs & temp curves. Pro unlocks 50-run history, stability scoring & clipboard export.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        OutlinedButton(
                            onClick = onNavigateToPremium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("reports_upgrade_pro_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonPurple)
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Explore GAMEBOOST Pro", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Section Title: Validation History & Comparisons
        item {
            Text(
                text = "Controlled Validation Reports (${visibleSessions.size})",
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Clearly-labelled AdMob Native Sponsored Content (only shown when real NativeAd loads and ads are permitted)
        if (shouldShowSponsoredCard) {
            item {
                com.example.ui.components.AdMobNativeSponsoredCard(
                    visibilityContext = nativeAdVisibility,
                    adManager = adManager,
                    testTagName = "reports_native_sponsored_card"
                )
            }
        }

        items(visibleSessions) { report ->
            BenchmarkReportCard(report = report)
        }

        // Hardware Profile Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Assessment, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                        Text(text = "Device Hardware Baseline", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    ReportRow(label = "Device Model", value = stats.deviceModel)
                    ReportRow(label = "Hardware Chipset", value = stats.cpuModel)
                    ReportRow(label = "SoC Board", value = stats.cpuBoard)
                    ReportRow(label = "Display Refresh Rate", value = "${stats.displayRefreshRate.toInt()} Hz")
                    ReportRow(label = "Thermal Headroom API", value = if (stats.isThermalHeadroomSupported) "${(stats.thermalHeadroom * 100).toInt()}%" else "Unsupported on this device")
                    ReportRow(label = "PowerManager Thermal Status", value = if (stats.isThermalStatusSupported) "Supported (API 29+)" else "Unsupported (< Android 10)")
                    ReportRow(label = "Total System RAM", value = "${stats.totalMemoryGb} GB")
                    ReportRow(label = "Android Version", value = "Android ${stats.androidVersion} (API ${stats.sdkInt})")
                }
            }
        }

        // Transparent FPS Testing Guide Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.FactCheck, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                        Text(text = "Scientific FPS Validation Guide", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(
                        text = "1. Control Test Variables: Use the same phone, game map, graphics settings, room temperature, and test duration (e.g. exactly 10 minutes).\n" +
                                "2. Unrooted Android Sandbox: Android security policies strictly isolate other apps' frame buffers. No standard third-party app can read another game's live FPS without root, Shizuku, or ADB.\n" +
                                "3. Validating Frame Rate: If your phone includes a manufacturer gaming overlay (e.g., Xiaomi Game Turbo, ASUS Armoury Crate, Samsung Game Plugins, OnePlus Games) or you connect via ADB dumpsys gfxinfo, record those observed numbers into the session logger above.\n" +
                                "4. Real Hardware Correlation: Even without an FPS counter, PowerManager thermal throttling status, battery temperature rise, and RAM exhaustion indicate whether device clock speeds are being throttled.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Bottom Reports Adaptive Banner Slot (non-overlapping, suppressed in Pro / active sessions / warnings)
        if (shouldShowReportsBanner) {
            item {
                com.example.ui.components.AdMobAdaptiveBannerSlot(
                    visibilityContext = reportsBannerVisibility,
                    adManager = adManager,
                    testTagName = "reports_ad_banner_slot"
                )
            }
        }
    }

    // Dialog when completing benchmark session to enter OEM observed FPS or leave blank
    if (showStopDialog) {
        AlertDialog(
            onDismissRequest = { showStopDialog = false },
            containerColor = DarkSurface,
            title = { Text("Log Final Session Metrics", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "If an OEM game overlay or developer FPS tool was active, enter your observed frame rate below. If not, leave blank to record as 'FPS Unavailable'.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = inputAvgFpsText,
                        onValueChange = { inputAvgFpsText = it },
                        label = { Text("Observed Average FPS (Optional)", fontSize = 11.sp) },
                        placeholder = { Text("e.g. 30.5", fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkSurfaceBorder
                        )
                    )
                    OutlinedTextField(
                        value = inputMinFpsText,
                        onValueChange = { inputMinFpsText = it },
                        label = { Text("Observed 1% Low / Min FPS (Optional)", fontSize = 11.sp) },
                        placeholder = { Text("e.g. 24.0", fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkSurfaceBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val avg = inputAvgFpsText.toFloatOrNull()
                        val min = inputMinFpsText.toFloatOrNull()
                        showStopDialog = false
                        onStopBenchmark(avg, min)
                        inputAvgFpsText = ""
                        inputMinFpsText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Save Report", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showStopDialog = false
                    onStopBenchmark(null, null)
                    inputAvgFpsText = ""
                    inputMinFpsText = ""
                }) {
                    Text("Save as 'FPS Unavailable'", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun BenchmarkReportCard(report: BenchmarkSessionReport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = report.sessionLabel, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${report.gameTitle} • Settings: ${report.graphicsSettings}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (report.throttlingObserved) NeonRed.copy(alpha = 0.15f) else NeonGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (report.throttlingObserved) "THROTTLING REPORTED" else "STABLE TELEMETRY",
                        color = if (report.throttlingObserved) NeonRed else NeonGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = DarkSurfaceBorder)

            // FPS Row: Truthful representation
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "Average Measured FPS", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (report.measuredAvgFps != null) "${report.measuredAvgFps} FPS" else "Unavailable (Sandbox Protected)",
                        color = if (report.measuredAvgFps != null) NeonCyan else TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "1% Low / Min FPS", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (report.measuredMinFps != null) "${report.measuredMinFps} FPS" else "Unavailable",
                        color = if (report.measuredMinFps != null) TextPrimary else TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            // Frame-Time & Refresh Rate
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "Calculated Frame-Time", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (report.measuredFrameTimeMs != null) "~${report.measuredFrameTimeMs} ms" else "Unavailable",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Display Refresh Rate", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "${report.displayRefreshRateHz.toInt()} Hz Display",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Thermal & Battery Changes
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "Battery Temp Change", color = TextSecondary, fontSize = 11.sp)
                    val hasTemp = report.startTempC > 0f && report.peakTempC > 0f
                    val delta = report.peakTempC - report.startTempC
                    val deltaSign = if (delta >= 0) "+" else ""
                    Text(
                        text = if (hasTemp) {
                            "${report.startTempC}°C → ${report.peakTempC}°C ($deltaSign${String.format(Locale.US, "%.1f", delta)}°C)"
                        } else {
                            "N/A"
                        },
                        color = if (hasTemp && report.peakTempC >= 41f) NeonRed else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Battery Drain", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "${report.startBatteryLevel}% → ${report.endBatteryLevel}% (${report.endBatteryLevel - report.startBatteryLevel}%)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp
                    )
                }
            }

            // PowerManager Thermal Status
            Column {
                Text(text = "OS Thermal Status (Start → Peak)", color = TextSecondary, fontSize = 11.sp)
                Text(
                    text = "${report.startThermalStatus} → ${report.peakThermalStatus}",
                    color = if (report.throttlingObserved) NeonRed else TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // RAM and TCP Latency
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "RAM (Min / Avg Free)", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "${report.minAvailRamGb} GB / ${report.avgAvailRamGb} GB Free",
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "TCP Gateway Latency", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (report.avgPingMs > 0) "Avg ${report.avgPingMs}ms • Jitter ${report.avgJitterMs}ms" else "Not Tested (N/A)",
                        color = if (report.avgPingMs > 0) NeonCyan else TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            // Source note & Session Analysis Conclusion
            val comparisonDetails = remember(report) {
                com.example.data.PerformanceAdvisorEngine.generateSessionComparisonReport(report)
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Source: ${report.fpsMeasurementSource}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = NeonCyan.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = comparisonDetails.confidenceTag,
                            color = NeonCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = comparisonDetails.evaluationVerdict,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun ReportRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Text(text = value, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

internal fun buildProTelemetryReportSummary(
    stats: DeviceStats,
    sessions: List<BenchmarkSessionReport>,
    stabilityPct: Int
): String {
    val sb = StringBuilder()
    sb.appendLine("GAMEBOOST PRO — Telemetry & Stability Report")
    sb.appendLine("Device: ${stats.deviceModel} | SoC: ${stats.cpuModel} | Android ${stats.androidVersion} (API ${stats.sdkInt})")
    sb.appendLine("Sessions Analyzed: ${sessions.size} | Thermal Stability Rate: $stabilityPct%")
    sb.appendLine("---")
    sessions.take(10).forEachIndexed { idx, s ->
        val avgFpsStr = s.measuredAvgFps?.let { "${it} FPS" } ?: "FPS N/A"
        val tempStr = if (s.startTempC > 0f && s.peakTempC > 0f) "Temp ${s.startTempC}°C->${s.peakTempC}°C" else "Temp N/A"
        val pingStr = if (s.avgPingMs > 0) "Ping ${s.avgPingMs}ms" else "Ping N/A"
        sb.appendLine(
            "${idx + 1}. ${s.sessionLabel} (${s.gameTitle}) | ${s.durationSeconds}s | " +
                "$tempStr | Bat ${s.startBatteryLevel}%->${s.endBatteryLevel}% | " +
                "$avgFpsStr | $pingStr | Throttled=${s.throttlingObserved}"
        )
    }
    return sb.toString().trim()
}


