package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.*
import com.example.data.ProtectionSeverity
import com.example.ui.components.AdMobAdaptiveBannerSlot
import com.example.ui.theme.*

import androidx.compose.ui.platform.testTag
@Composable
fun ToolsHubScreen(
    isPremium: Boolean = false,
    isGamingSessionActive: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onNavigateToScan: () -> Unit,
    onNavigateToNetwork: () -> Unit,
    onNavigateToAim: () -> Unit,
    onNavigateToLab: () -> Unit,
    onNavigateToDeviceControl: () -> Unit,
    onNavigateToSmartGaming: () -> Unit = {},
    onNavigateToPremium: () -> Unit = {}
) {
    val adState by adManager.adState.collectAsState()
    val toolsVisibility = AdVisibilityContext(
        location = AdScreenLocation.TOOLS_HUB,
        isGamingSessionActive = isGamingSessionActive || isAutopilotActive,
        isAutopilotSessionActive = isAutopilotActive,
        thermalSeverity = thermalSeverity
    )
    val shouldShowToolsBanner = !isPremium && remember(adState, toolsVisibility) {
        adManager.canDisplayAds(toolsVisibility)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (shouldShowToolsBanner) {
            item {
                AdMobAdaptiveBannerSlot(
                    visibilityContext = toolsVisibility,
                    adManager = adManager,
                    testTagName = "tools_hub_ad_banner_slot"
                )
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "GAMING TOOLS",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                }
                Text(
                    text = "Diagnostics, network, aim lab & autopilot controls",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Category 1: System & Hardware Diagnostics
        item {
            Text(
                text = "Hardware & Storage",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            ToolLauncherCard(
                title = "Device Diagnostics Lab",
                subtitle = "Storage, multi-touch, display Hz & battery metrics",
                icon = Icons.Default.Security,
                accentColor = NeonCyan,
                badge = "5 Tests",
                modifier = Modifier.testTag("tool_card_scan"),
                onClick = onNavigateToScan
            )
        }

        // Category 2: Connection & Latency
        item {
            Text(
                text = "Network & Connectivity",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            ToolLauncherCard(
                title = "Network Intelligence",
                subtitle = "Gateway ping, RFC 3393 jitter & live throughput",
                icon = Icons.Default.Wifi,
                accentColor = NeonGreen,
                badge = "Ping & Jitter",
                modifier = Modifier.testTag("tool_card_network"),
                onClick = onNavigateToNetwork
            )
        }

        // Category 3: Control & Precision
        item {
            Text(
                text = "Controls & Aim Training",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            ToolLauncherCard(
                title = "Aim & Control Lab",
                subtitle = "Sensitivity calculator, gyro, 360° pad & aim trainer",
                icon = Icons.Default.GpsFixed,
                accentColor = NeonRed,
                badge = "Aim Trainer",
                modifier = Modifier.testTag("tool_card_aim"),
                onClick = onNavigateToAim
            )
        }

        // Category 4: Stress Testing
        item {
            Text(
                text = "Performance & Workload Testing",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            ToolLauncherCard(
                title = "Benchmark Lab",
                subtitle = "CPU math, memory & Canvas frame load with thermal guard",
                icon = Icons.Default.Speed,
                accentColor = NeonPurple,
                badge = "CPU / Mem / GPU",
                modifier = Modifier.testTag("tool_card_lab"),
                onClick = onNavigateToLab
            )
        }

        // Category 5: System Control & OEM Integration
        item {
            Text(
                text = "System Control & Membership",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            ToolLauncherCard(
                title = "Gaming Autopilot",
                subtitle = "Auto brightness, DND, timeout & background advisor",
                icon = Icons.Default.AutoMode,
                accentColor = NeonGreen,
                badge = "Autopilot",
                modifier = Modifier.testTag("tool_card_autopilot"),
                onClick = onNavigateToSmartGaming
            )
        }

        item {
            ToolLauncherCard(
                title = "Device Control Engine",
                subtitle = "Safe optimization profiles, Dev Options & OEM Hub",
                icon = Icons.Default.Tune,
                accentColor = NeonCyan,
                badge = "Authorized Engine",
                modifier = Modifier.testTag("tool_card_device_control"),
                onClick = onNavigateToDeviceControl
            )
        }

        item {
            ToolLauncherCard(
                title = if (isPremium) "GAMEBOOST Pro Active" else "GAMEBOOST Pro",
                subtitle = if (isPremium) "Ad-free mode, 50-session history & Pro HUD unlocked" else "Ad-free experience, Pro overlay themes & 50-run history",
                icon = Icons.Default.Stars,
                accentColor = NeonPurple,
                badge = if (isPremium) "PRO" else "Upgrade",
                modifier = Modifier.testTag("tool_card_premium"),
                onClick = onNavigateToPremium
            )
        }
    }
}

@Composable
fun ToolLauncherCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    badge: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = accentColor.copy(alpha = 0.15f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = badge,
                            color = accentColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
