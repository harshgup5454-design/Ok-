package com.example.ui.screens

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceControlScreen(
    capabilities: DeviceCapabilities,
    controlState: SystemControlState,
    savedSystemState: SavedSystemStateEntity?,
    profileApplyMessage: String?,
    onRefreshCapabilities: (Context) -> Unit,
    onApplyProfile: (Context, ProfileType, (String) -> Unit) -> Unit,
    onRestoreOriginals: (Context) -> Unit,
    onUpdateBrightness: (Context, Int, Int) -> Unit,
    onUpdateTimeout: (Context, Int) -> Unit,
    onUpdateAutoRotate: (Context, Int) -> Unit,
    onUpdateDndFilter: (Context, Int) -> Unit,
    onLaunchOemGamingSpace: (Context) -> Boolean,
    onClearMessage: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedProfileForDialog by remember { mutableStateOf<ProfileType?>(null) }
    var expandedProfileCard by remember { mutableStateOf<ProfileType?>(ProfileType.SMOOTHNESS_FOCUS) }

    LaunchedEffect(Unit) {
        onRefreshCapabilities(context)
    }

    LaunchedEffect(profileApplyMessage) {
        if (!profileApplyMessage.isNullOrBlank()) {
            Toast.makeText(context, profileApplyMessage, Toast.LENGTH_LONG).show()
            onClearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "DEVICE CONTROL ENGINE",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Authorized Android System Settings & Manufacturer Integration",
                            color = TextSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                    }
                },
                actions = {
                    IconButton(onClick = { onRefreshCapabilities(context) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Capabilities", tint = NeonCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // PHASE 1: Device Capability & OEM Detection
            item {
                DeviceCapabilitiesHeaderCard(
                    capabilities = capabilities,
                    onLaunchOem = {
                        val launched = onLaunchOemGamingSpace(context)
                        if (!launched) {
                            Toast.makeText(context, "Could not launch OEM Gaming Space", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            // PHASE 6: Safe Optimization Profiles
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                            Text(
                                text = "SAFE OPTIMIZATION PROFILES",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (savedSystemState != null) {
                            OutlinedButton(
                                onClick = { onRestoreOriginals(context) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonOrange),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restore Originals", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Text(
                        text = "Profiles control ONLY settings GAMEBOOST is authorized to change. Baseline system values are saved prior to changes.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    ProfileType.values().forEach { profileType ->
                        val profile = DeviceControlEngine.getProfileDefinition(profileType)
                        val isApplied = savedSystemState?.appliedProfileName == profile.displayName

                        OptimizationProfileCard(
                            profile = profile,
                            isApplied = isApplied,
                            isExpanded = expandedProfileCard == profileType,
                            onToggleExpand = {
                                expandedProfileCard = if (expandedProfileCard == profileType) null else profileType
                            },
                            onApplyClick = {
                                selectedProfileForDialog = profileType
                            }
                        )
                    }
                }
            }

            // PHASE 2: Authorized Settings Control Panel
            item {
                AuthorizedControlsPanelCard(
                    controlState = controlState,
                    capabilities = capabilities,
                    onUpdateBrightness = { mode, level -> onUpdateBrightness(context, mode, level) },
                    onUpdateTimeout = { timeoutMs -> onUpdateTimeout(context, timeoutMs) },
                    onUpdateAutoRotate = { rotate -> onUpdateAutoRotate(context, rotate) },
                    onUpdateDndFilter = { filter -> onUpdateDndFilter(context, filter) },
                    onGrantWriteSettings = {
                        try {
                            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                data = android.net.Uri.parse("package:${context.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Open Settings > Apps > Special App Access > Modify System Settings", Toast.LENGTH_LONG).show()
                        }
                    },
                    onGrantDndAccess = {
                        try {
                            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Open Settings > Apps > Special Access > Do Not Disturb Access", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }

            // PHASE 4: Display and Power Advisor
            item {
                DisplayPowerAdvisorCard(
                    capabilities = capabilities,
                    onOpenBatterySaverSettings = {
                        try {
                            val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    }
                )
            }

            // PHASE 3: Developer Options Assistant
            item {
                DeveloperOptionsAssistantCard(
                    onOpenDeveloperOptions = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                                Toast.makeText(context, "Open System > Developer Options", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {}
                        }
                    }
                )
            }

            // PHASE 7: Transparency & Restoration Record
            item {
                RestoreTransparencyCard(
                    savedState = savedSystemState,
                    currentState = controlState,
                    onRestoreOriginals = { onRestoreOriginals(context) }
                )
            }
        }
    }

    // Profile Apply Confirmation Dialog
    selectedProfileForDialog?.let { profileType ->
        val profile = DeviceControlEngine.getProfileDefinition(profileType)
        AlertDialog(
            onDismissRequest = { selectedProfileForDialog = null },
            containerColor = DarkSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan)
                    Text("Apply ${profile.displayName}?", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "GAMEBOOST will apply authorized system adjustments. Your original system baseline will be saved so you can revert anytime.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    HorizontalDivider(color = DarkSurfaceBorder)

                    Text("Settings to be changed:", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    profile.appliedAuthorizedSettings.forEach { item ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(14.dp))
                            Text(item, color = TextPrimary, fontSize = 11.sp)
                        }
                    }

                    if (profile.manualRecommendations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Recommended Manual Actions:", color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        profile.manualRecommendations.forEach { item ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(14.dp))
                                Text(item, color = TextSecondary, fontSize = 10.5.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = selectedProfileForDialog
                        selectedProfileForDialog = null
                        if (target != null) {
                            onApplyProfile(context, target) { missingPermission ->
                                Toast.makeText(context, "Permission Required: $missingPermission", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Confirm & Apply", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProfileForDialog = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

// ==========================================
// COMPOSABLE COMPONENT CARDS
// ==========================================

@Composable
fun DeviceCapabilitiesHeaderCard(
    capabilities: DeviceCapabilities,
    onLaunchOem: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${capabilities.manufacturer.uppercase()} ${capabilities.model}",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Android ${capabilities.androidVersion} (API ${capabilities.sdkInt})",
                        color = NeonCyan,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant
                ) {
                    Text(
                        text = "${capabilities.currentRefreshRateHz.toInt()} Hz Current",
                        color = NeonGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = DarkSurfaceBorder)

            // Capabilities Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CapChip(
                    modifier = Modifier.weight(1f),
                    label = "Supported Rates",
                    value = capabilities.supportedRefreshRates.joinToString(" / ") { "${it.toInt()}Hz" },
                    tint = NeonCyan
                )
                CapChip(
                    modifier = Modifier.weight(1f),
                    label = "Battery Saver",
                    value = if (capabilities.isBatterySaverOn) "ACTIVE" else "OFF",
                    tint = if (capabilities.isBatterySaverOn) NeonOrange else NeonGreen
                )
                CapChip(
                    modifier = Modifier.weight(1f),
                    label = "OS Thermal",
                    value = capabilities.thermalStatusDesc.take(10),
                    tint = if (capabilities.thermalStatusCode >= 2) NeonRed else NeonGreen
                )
            }

            // OEM Gaming Mode Detection Strip
            val oem = capabilities.oemGamingSpace
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (oem?.isAvailable == true) Icons.Default.Launch else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (oem?.isAvailable == true) NeonCyan else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = if (oem?.isAvailable == true) "OEM Gaming Hub: ${oem.name}" else "Native Android Gaming Engine Active",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = if (oem?.isAvailable == true) "Official manufacturer gaming interface detected" else "Standard Android system APIs in use",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    if (oem?.isAvailable == true) {
                        Button(
                            onClick = onLaunchOem,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Open OEM Hub", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CapChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    tint: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = DarkSurfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(label, color = TextSecondary, fontSize = 9.5.sp)
            Text(value, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
fun OptimizationProfileCard(
    profile: OptimizationProfile,
    isApplied: Boolean,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onApplyClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isApplied) DarkSurfaceVariant else DarkSurface
        ),
        border = if (isApplied) androidx.compose.foundation.BorderStroke(1.dp, NeonCyan) else null
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = when (profile.type) {
                            ProfileType.BALANCED -> Icons.Default.Balance
                            ProfileType.SMOOTHNESS_FOCUS -> Icons.Default.Speed
                            ProfileType.BATTERY_FRIENDLY -> Icons.Default.BatterySaver
                        },
                        contentDescription = null,
                        tint = when (profile.type) {
                            ProfileType.BALANCED -> NeonCyan
                            ProfileType.SMOOTHNESS_FOCUS -> NeonGreen
                            ProfileType.BATTERY_FRIENDLY -> NeonOrange
                        },
                        modifier = Modifier.size(22.dp)
                    )

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = profile.displayName,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (isApplied) {
                                Surface(shape = RoundedCornerShape(4.dp), color = NeonCyan.copy(alpha = 0.2f)) {
                                    Text("ACTIVE", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                }
                            }
                        }
                        Text(text = profile.description, color = TextSecondary, fontSize = 10.5.sp, maxLines = 2)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onApplyClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isApplied) NeonCyan.copy(alpha = 0.2f) else NeonCyan
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = if (isApplied) "Re-apply" else "Apply",
                            color = if (isApplied) NeonCyan else Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(onClick = onToggleExpand, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Toggle Details",
                            tint = TextSecondary
                        )
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(color = DarkSurfaceBorder)

                    Text("Applied Authorized Settings:", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    profile.appliedAuthorizedSettings.forEach { setting ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(12.dp))
                            Text(setting, color = TextPrimary, fontSize = 10.5.sp)
                        }
                    }

                    Text("Recommended Manual User Actions:", color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    profile.manualRecommendations.forEach { rec ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(12.dp))
                            Text(rec, color = TextSecondary, fontSize = 10.5.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthorizedControlsPanelCard(
    controlState: SystemControlState,
    capabilities: DeviceCapabilities,
    onUpdateBrightness: (Int, Int) -> Unit,
    onUpdateTimeout: (Int) -> Unit,
    onUpdateAutoRotate: (Int) -> Unit,
    onUpdateDndFilter: (Int) -> Unit,
    onGrantWriteSettings: () -> Unit,
    onGrantDndAccess: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                    Text("AUTHORIZED SYSTEM CONTROLS", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Surface(shape = RoundedCornerShape(6.dp), color = NeonGreen.copy(alpha = 0.15f)) {
                    Text("Official Android APIs", color = NeonGreen, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }

            Text(
                text = "Directly modify authorized device system preferences. No WRITE_SECURE_SETTINGS, ADB, Shizuku, or hidden APIs are used.",
                color = TextSecondary,
                fontSize = 11.sp
            )

            // Permission Warning Banners if permissions missing
            if (!capabilities.canWriteSettings) {
                PermissionRequestBanner(
                    title = "Modify System Settings Permission Required",
                    description = "Required to control Screen Brightness Mode, Screen Timeout, and Auto-Rotate lock.",
                    onClickGrant = onGrantWriteSettings
                )
            }

            if (!capabilities.canAccessDnd) {
                PermissionRequestBanner(
                    title = "Do Not Disturb Access Required",
                    description = "Required to moderate incoming notification popups while playing matches.",
                    onClickGrant = onGrantDndAccess
                )
            }

            HorizontalDivider(color = DarkSurfaceBorder)

            // Control 1: Auto-Rotate Lock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Auto-Rotate Lock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    Text("Prevent accidental orientation switching", color = TextSecondary, fontSize = 10.sp)
                }
                Switch(
                    checked = controlState.autoRotate == 1,
                    onCheckedChange = { isChecked -> onUpdateAutoRotate(if (isChecked) 1 else 0) },
                    enabled = capabilities.canWriteSettings,
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                )
            }

            // Control 2: Screen Off Timeout
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Screen Off Timeout", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        60000 to "1 Min",
                        120000 to "2 Min",
                        300000 to "5 Min",
                        1800000 to "30 Min"
                    ).forEach { (ms, label) ->
                        FilterChip(
                            selected = controlState.screenTimeoutMs == ms,
                            onClick = { onUpdateTimeout(ms) },
                            enabled = capabilities.canWriteSettings,
                            label = { Text(label, fontSize = 10.5.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                selectedLabelColor = NeonCyan
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Control 3: Screen Brightness
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Screen Brightness", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    Text(
                        text = if (controlState.brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) "Auto-Brightness" else "${(controlState.brightnessLevel * 100) / 255}% Manual",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = controlState.brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC,
                        onClick = { onUpdateBrightness(Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC, controlState.brightnessLevel) },
                        enabled = capabilities.canWriteSettings,
                        label = { Text("Auto", fontSize = 10.5.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = controlState.brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
                        onClick = { onUpdateBrightness(Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL, controlState.brightnessLevel) },
                        enabled = capabilities.canWriteSettings,
                        label = { Text("Manual", fontSize = 10.5.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (controlState.brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL) {
                    Slider(
                        value = controlState.brightnessLevel.toFloat(),
                        onValueChange = { newLevel -> onUpdateBrightness(Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL, newLevel.toInt()) },
                        valueRange = 10f..255f,
                        enabled = capabilities.canWriteSettings,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }
            }

            // Control 4: Do Not Disturb Filter
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Do Not Disturb Notification Filter", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        NotificationManager.INTERRUPTION_FILTER_ALL to "All",
                        NotificationManager.INTERRUPTION_FILTER_PRIORITY to "Priority",
                        NotificationManager.INTERRUPTION_FILTER_ALARMS to "Alarms Only"
                    ).forEach { (filter, label) ->
                        FilterChip(
                            selected = controlState.dndFilter == filter,
                            onClick = { onUpdateDndFilter(filter) },
                            enabled = capabilities.canAccessDnd,
                            label = { Text(label, fontSize = 10.5.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonGreen.copy(alpha = 0.2f),
                                selectedLabelColor = NeonGreen
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRequestBanner(
    title: String,
    description: String,
    onClickGrant: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = NeonOrange.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonOrange.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                Text(description, color = TextSecondary, fontSize = 10.sp)
            }
            Button(
                onClick = onClickGrant,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text("Grant", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
            }
        }
    }
}

@Composable
fun DisplayPowerAdvisorCard(
    capabilities: DeviceCapabilities,
    onOpenBatterySaverSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                Text("DISPLAY & POWER ADVISOR", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            // Display Hz vs Game FPS Guidance
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSurfaceVariant
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Display Refresh Rate (Hz) vs In-Game Render FPS", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        text = "• Display Refresh Rate (Hz): The hardware screen scanning frequency (e.g. ${capabilities.currentRefreshRateHz.toInt()}Hz).\n" +
                                "• Game Render FPS: The frame rate produced per second by the game engine.\n" +
                                "• A 120Hz display screen does NOT automatically force a 30 FPS game to run at 120 FPS.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            // Battery Saver Detection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("System Battery Saver Status", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        text = if (capabilities.isBatterySaverOn) "Battery Saver ACTIVE (System limits CPU clock & caps display at 60Hz)" else "Battery Saver OFF (Full CPU performance available)",
                        color = if (capabilities.isBatterySaverOn) NeonOrange else NeonGreen,
                        fontSize = 10.5.sp
                    )
                }

                OutlinedButton(
                    onClick = onOpenBatterySaverSettings,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text("Power Settings", fontSize = 10.5.sp)
                }
            }
        }
    }
}

@Composable
fun DeveloperOptionsAssistantCard(
    onOpenDeveloperOptions: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(18.dp))
                    Text("DEVELOPER OPTIONS ASSISTANT", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Button(
                    onClick = onOpenDeveloperOptions,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text("Open Dev Options", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                }
            }

            Text(
                text = "Technical guidance for user-configurable Developer Options. GAMEBOOST never changes protected developer flags automatically.",
                color = TextSecondary,
                fontSize = 11.sp
            )

            HorizontalDivider(color = DarkSurfaceBorder)

            // Guidance Items
            DevOptionGuideItem(
                title = "Window, Transition & Animator Scale (Set to 0.5x)",
                explanation = "Speeds up system window transitions and menu popups. Note: Does not increase in-game render FPS.",
                isRecommended = true
            )

            DevOptionGuideItem(
                title = "Default USB Configuration (Set to Charging Only)",
                explanation = "Prevents unexpected MTP file-transfer dialog popups when plugging in charging cables during matches.",
                isRecommended = true
            )

            DevOptionGuideItem(
                title = "Disable Hardware Overlays",
                explanation = "Forces Android WindowManager to compose windows using GPU. Helpful if screen recorder overlay flickers.",
                isRecommended = false
            )

            // Explicit Warnings for Non-Recommended Flags
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = NeonRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Settings NOT Recommended For General Gaming:", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("• Force 4x MSAA: Causes severe GPU power draw & thermal throttling on mobile devices.\n• Background Process Limit: Can crash background services or chat apps.\n• Disabling Security / ADB Protection: Exposes device to malware risks.", color = TextSecondary, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
    }
}

@Composable
fun DevOptionGuideItem(
    title: String,
    explanation: String,
    isRecommended: Boolean
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = if (isRecommended) Icons.Default.CheckCircle else Icons.Default.Info,
            contentDescription = null,
            tint = if (isRecommended) NeonGreen else NeonOrange,
            modifier = Modifier.size(16.dp).padding(top = 2.dp)
        )
        Column {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Text(explanation, color = TextSecondary, fontSize = 10.5.sp)
        }
    }
}

@Composable
fun RestoreTransparencyCard(
    savedState: SavedSystemStateEntity?,
    currentState: SystemControlState,
    onRestoreOriginals: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                Text("RESTORE & SYSTEM TRANSPARENCY", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            if (savedState != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceVariant
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Recorded System Baseline (Saved before optimization):", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("• Applied Profile: ${savedState.appliedProfileName}", color = TextPrimary, fontSize = 10.5.sp)
                        Text("• Original Screen Timeout: ${savedState.originalScreenTimeoutMs / 1000}s", color = TextSecondary, fontSize = 10.5.sp)
                        Text("• Original Auto-Rotate: ${if (savedState.originalAutoRotate == 1) "ON" else "LOCKED"}", color = TextSecondary, fontSize = 10.5.sp)
                        Text("• Original Brightness Level: ${savedState.originalBrightnessLevel} / 255", color = TextSecondary, fontSize = 10.5.sp)
                    }
                }

                Button(
                    onClick = onRestoreOriginals,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Restore Original System Settings", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            } else {
                Text(
                    text = "No active optimization profile applied. System baseline will be recorded automatically when a profile is activated.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}
