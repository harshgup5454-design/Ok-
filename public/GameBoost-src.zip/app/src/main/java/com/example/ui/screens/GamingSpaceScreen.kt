package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.*
import com.example.data.*
import com.example.ui.components.AdMobAdaptiveBannerSlot
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun GamingSpaceScreen(
    profiles: List<GameProfile>,
    deviceStats: DeviceStats,
    isBenchmarking: Boolean,
    benchmarkSeconds: Int,
    benchmarkSessions: List<BenchmarkSessionReport>,
    installedApps: List<InstalledAppItem>,
    isLoadingApps: Boolean,
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onRefreshApps: () -> Unit,
    onAddGameToVault: (String, String) -> Unit,
    onRemoveGameFromVault: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onUpdateFullProfile: (GameProfile) -> Unit,
    onRestorePreviousProfile: (String) -> Unit = {},
    onDeleteProfilePermanently: (String) -> Unit = {},
    onLaunchGame: (GameProfile, Boolean) -> Boolean,
    onStopSession: () -> Unit,
    onOpenSidebarPreview: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0 = Game Vault, 1 = FPS Guides, 2 = Sessions
    var showAddGameDialog by remember { mutableStateOf(false) }
    var tuningProfile by remember { mutableStateOf<GameProfile?>(null) }
    var autoTrackOnLaunch by remember { mutableStateOf(true) }
    var notInstalledMessage by remember { mutableStateOf<String?>(null) }

    val vaultGames = remember(profiles) { profiles.filter { it.isInLibrary } }

    val adState by adManager.adState.collectAsState()
    val spaceVisibility = AdVisibilityContext(
        location = AdScreenLocation.GAME_SPACE,
        isGamingSessionActive = isBenchmarking || isAutopilotActive,
        isAutopilotSessionActive = isAutopilotActive,
        isBenchmarking = isBenchmarking,
        isPermissionOrLoadingActive = isLoadingApps,
        thermalSeverity = thermalSeverity
    )
    val shouldShowSpaceBanner = !isPremium && remember(adState, spaceVisibility) {
        adManager.canDisplayAds(spaceVisibility)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (shouldShowSpaceBanner) {
            item {
                AdMobAdaptiveBannerSlot(
                    visibilityContext = spaceVisibility,
                    adManager = adManager,
                    testTagName = "game_space_ad_banner_slot"
                )
            }
        }

        // Gaming Space Header & Telemetry Strip
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.SportsEsports, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(26.dp))
                            Text(
                                text = "GAMING SPACE",
                                color = TextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.1.sp
                            )
                        }
                        Text(
                            text = "Offline Game Vault, Launch Hub & Hardware Companion",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    IconButton(
                        onClick = onOpenSidebarPreview,
                        colors = IconButtonDefaults.iconButtonColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.MenuOpen, contentDescription = "Sidebar Preview", tint = NeonCyan)
                    }
                }

                // Device Performance Summary Strip
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Real-Time Hardware Status", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NeonGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "${deviceStats.displayRefreshRate.toInt()} Hz Display",
                                    color = NeonGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HardwareChip(
                                modifier = Modifier.weight(1f),
                                label = "Free RAM",
                                value = "${deviceStats.availableMemoryGb} GB",
                                sub = "${deviceStats.memoryUsagePercent}% used",
                                tint = if (deviceStats.memoryUsagePercent > 85) NeonOrange else NeonCyan
                            )
                            val hasTemp = deviceStats.batteryTemperatureC > 0f
                            HardwareChip(
                                modifier = Modifier.weight(1f),
                                label = "Battery Temp",
                                value = if (hasTemp) "${deviceStats.batteryTemperatureC}°C" else "N/A",
                                sub = if (deviceStats.isCharging) "Charging" else "On Battery",
                                tint = if (!hasTemp) TextSecondary else if (deviceStats.batteryTemperatureC >= 39.5f) NeonRed else NeonGreen
                            )
                            HardwareChip(
                                modifier = Modifier.weight(1f),
                                label = "OS Thermal",
                                value = deviceStats.powerManagerThermalStatus.take(8),
                                sub = if (deviceStats.powerManagerThermalStatusCode >= 2) "Throttling" else "Normal",
                                tint = if (deviceStats.powerManagerThermalStatusCode >= 2) NeonRed else NeonGreen
                            )
                        }

                        // Active Session Bar if monitoring is live
                        if (isBenchmarking) {
                            HorizontalDivider(color = DarkSurfaceBorder)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(NeonRed)
                                    )
                                    Text(
                                        text = "Session Monitoring Active (${String.format(Locale.US, "%02d:%02d", benchmarkSeconds / 60, benchmarkSeconds % 60)})",
                                        color = NeonRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                                Button(
                                    onClick = onStopSession,
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.2f)),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text("Stop & Save", color = NeonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Navigation Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("My Vault (${vaultGames.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                        selectedLabelColor = NeonCyan
                    ),
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("Tuning Guides") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonGreen.copy(alpha = 0.2f),
                        selectedLabelColor = NeonGreen
                    ),
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text("Sessions (${benchmarkSessions.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonPurple.copy(alpha = 0.2f),
                        selectedLabelColor = NeonPurple
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Game Vault Tab
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Installed Game Vault", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Button(
                            onClick = {
                                onRefreshApps()
                                showAddGameDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Game", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Auto-track session telemetry on launch", color = TextPrimary, fontSize = 12.sp)
                            Text(text = "Logs battery temp, OS thermal status, and RAM usage while playing", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = autoTrackOnLaunch,
                            onCheckedChange = { autoTrackOnLaunch = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan, checkedTrackColor = DarkSurfaceVariant)
                        )
                    }
                }

                if (vaultGames.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.SportsEsports, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                                Text("No games in your vault yet", color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text(
                                    "Add games installed on your device to launch them directly with GameBoost overlay assistance.",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Button(
                                    onClick = {
                                        onRefreshApps()
                                        showAddGameDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                                ) {
                                    Text("Browse Installed Apps", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(vaultGames) { game ->
                        GameVaultCard(
                            game = game,
                            context = context,
                            onLaunch = {
                                val launched = onLaunchGame(game, autoTrackOnLaunch)
                                if (!launched) {
                                    notInstalledMessage = "${game.name} is not installed or has no launchable activity on this device."
                                }
                            },
                            onTune = { tuningProfile = game },
                            onRestorePrevious = {
                                onRestorePreviousProfile(game.id)
                                Toast.makeText(context, "Restored previous profile for ${game.name}", Toast.LENGTH_SHORT).show()
                            },
                            onToggleFavorite = { onToggleFavorite(game.id) },
                            onRemove = { onRemoveGameFromVault(game.id) }
                        )
                    }
                }
            }

            1 -> {
                // Tactical Graphics Guides Tab
                item {
                    Text(
                        text = "Verified In-Game Configuration Guides",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                items(profiles.take(5)) { profile ->
                    GameTuningGuideCard(profile = profile)
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                                Text(text = "Engineering Transparency & Anti-Cheat", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text(
                                text = "GameBoost does not inject into game memory, modify APK/OBB assets, or claim impossible GPU boosting. The settings above represent realistic graphics configurations to apply inside the game menus to sustain target frame rates without severe thermal throttling.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            2 -> {
                // Sessions Recap Tab
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Recorded Gaming Sessions", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (isBenchmarking) {
                            Surface(shape = RoundedCornerShape(6.dp), color = NeonRed.copy(alpha = 0.2f)) {
                                Text(
                                    text = "RECORDING NOW",
                                    color = NeonRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                if (benchmarkSessions.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Assessment, contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp))
                                Text("No recorded sessions yet", color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text(
                                    "Launch any game from your vault with auto-tracking enabled to log battery drain, temperature delta, and thermal throttling.",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    items(benchmarkSessions) { session ->
                        SessionSummaryCard(session = session)
                    }
                }
            }
        }
    }

    // Add Game Dialog
    if (showAddGameDialog) {
        AddGameDialog(
            installedApps = installedApps,
            isLoading = isLoadingApps,
            onDismiss = { showAddGameDialog = false },
            onSelectApp = { app ->
                onAddGameToVault(app.appName, app.packageName)
                showAddGameDialog = false
                Toast.makeText(context, "Added ${app.appName} to Gaming Space", Toast.LENGTH_SHORT).show()
            },
            onManualAdd = { customName, customPkg ->
                onAddGameToVault(customName, customPkg)
                showAddGameDialog = false
                Toast.makeText(context, "Added $customName ($customPkg)", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Full Profile Tuning Dialog
    tuningProfile?.let { profile ->
        FullGameProfileDialog(
            profile = profile,
            onDismiss = { tuningProfile = null },
            onDelete = {
                onDeleteProfilePermanently(profile.id)
                tuningProfile = null
                Toast.makeText(context, "Deleted profile ${profile.name}", Toast.LENGTH_SHORT).show()
            },
            onSave = { updated ->
                onUpdateFullProfile(updated)
                tuningProfile = null
                Toast.makeText(context, "Profile updated for ${updated.name}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Not Installed Warning Dialog
    notInstalledMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { notInstalledMessage = null },
            containerColor = DarkSurface,
            title = { Text("App Not Found", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = msg,
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { notInstalledMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("OK", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun HardwareChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    sub: String,
    tint: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = label, color = TextSecondary, fontSize = 10.sp)
            Text(text = value, color = tint, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(text = sub, color = TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable
fun GameVaultCard(
    game: GameProfile,
    context: Context,
    onLaunch: () -> Unit,
    onTune: () -> Unit,
    onRestorePrevious: () -> Unit = {},
    onToggleFavorite: () -> Unit,
    onRemove: () -> Unit
) {
    val appIcon: ImageBitmap? = remember(game.packageName) {
        GameSpaceManager.getAppIcon(context, game.packageName)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Game Icon or Fallback
                    Surface(
                        modifier = Modifier.size(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (appIcon != null) {
                                Image(
                                    bitmap = appIcon,
                                    contentDescription = game.name,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.SportsEsports,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = game.name,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "${game.performanceMode.displayName} • ${game.fpsLock} FPS Target",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (game.previousMode != null) {
                            Text(
                                text = "Previous: ${game.previousMode.displayName} (${game.previousFpsLock} FPS)",
                                color = TextMuted,
                                fontSize = 9.5.sp
                            )
                        }
                        if (game.customNotes.isNotBlank()) {
                            Text(
                                text = game.customNotes,
                                color = TextSecondary,
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = if (game.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (game.isFavorite) NeonRed else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(onClick = onRemove, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Remove from Vault",
                            tint = TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = DarkSurfaceBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onTune,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tune", fontSize = 11.5.sp)
                    }
                    if (game.previousMode != null) {
                        OutlinedButton(
                            onClick = onRestorePrevious,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonPurple),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.History, contentDescription = "Restore previous profile", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Undo", fontSize = 11.5.sp)
                        }
                    }
                }

                Button(
                    onClick = onLaunch,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PLAY", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun GameTuningGuideCard(profile: GameProfile) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = profile.name,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Target Goal: ${profile.performanceMode.displayName}",
                        color = NeonCyan,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = NeonGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "VERIFIED GUIDE",
                        color = NeonGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = DarkSurfaceBorder)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Recommended Graphics", color = TextSecondary, fontSize = 10.sp)
                    Text(text = profile.recommendedGraphics, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(text = "Target Frame Rate", color = TextSecondary, fontSize = 10.sp)
                    Text(text = profile.recommendedFpsCap, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Shadows", color = TextSecondary, fontSize = 10.sp)
                    Text(text = profile.shadowSetting, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(text = "Anti-Aliasing", color = TextSecondary, fontSize = 10.sp)
                    Text(text = profile.antiAliasing, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider(color = DarkSurfaceBorder)

                    Text(text = "Thermal Advice:", color = NeonOrange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(text = profile.thermalAdvice, color = TextSecondary, fontSize = 11.sp)

                    Text(text = "Battery Management:", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(text = profile.batteryAdvice, color = TextSecondary, fontSize = 11.sp)

                    Text(text = "Network Stability:", color = NeonPurple, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(text = profile.networkAdvice, color = TextSecondary, fontSize = 11.sp)

                    Text(text = "Realistic Device Limitations:", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(text = profile.deviceLimitations, color = TextSecondary, fontSize = 11.sp)
                }
            }

            TextButton(
                onClick = { isExpanded = !isExpanded },
                modifier = Modifier.align(Alignment.CenterHorizontally),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                Text(
                    text = if (isExpanded) "Show Less" else "View Detailed Thermal & Device Advice",
                    color = NeonCyan,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun SessionSummaryCard(session: BenchmarkSessionReport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = session.gameTitle, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = "${session.durationSeconds / 60}m ${session.durationSeconds % 60}s",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Battery Temp", color = TextSecondary, fontSize = 10.sp)
                    val tempText = if (session.startTempC > 0f && session.peakTempC > 0f) {
                        "${session.startTempC}°C → ${session.peakTempC}°C"
                    } else {
                        "N/A"
                    }
                    Text(text = tempText, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Battery Drain", color = TextSecondary, fontSize = 10.sp)
                    Text(text = "${session.startBatteryLevel}% → ${session.endBatteryLevel}%", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Throttling", color = TextSecondary, fontSize = 10.sp)
                    Text(
                        text = if (session.throttlingObserved) "Observed" else "None",
                        color = if (session.throttlingObserved) NeonRed else NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Text(
                text = session.conclusion,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
fun AddGameDialog(
    installedApps: List<InstalledAppItem>,
    isLoading: Boolean,
    onDismiss: () -> Unit,
    onSelectApp: (InstalledAppItem) -> Unit,
    onManualAdd: (String, String) -> Unit = { _, _ -> }
) {
    var searchQuery by remember { mutableStateOf("") }
    var isManualEntry by remember { mutableStateOf(false) }
    var manualName by remember { mutableStateOf("") }
    var manualPackage by remember { mutableStateOf("") }

    val filteredApps = remember(searchQuery, installedApps) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter { it.appName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("Add Game to Vault", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !isManualEntry,
                        onClick = { isManualEntry = false },
                        label = { Text("Installed (${installedApps.size})", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = isManualEntry,
                        onClick = { isManualEntry = true },
                        label = { Text("Manual Package", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (isManualEntry) {
                    Text(
                        text = "Enter any game title and Android package name (e.g. com.dts.freefiremax).",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    OutlinedTextField(
                        value = manualName,
                        onValueChange = { manualName = it },
                        label = { Text("Game Title", fontSize = 11.sp) },
                        placeholder = { Text("e.g. Free Fire MAX", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = manualPackage,
                        onValueChange = { manualPackage = it },
                        label = { Text("Package Name", fontSize = 11.sp) },
                        placeholder = { Text("e.g. com.dts.freefiremax", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            if (manualPackage.isNotBlank()) {
                                onManualAdd(manualName.ifBlank { manualPackage.substringAfterLast('.') }, manualPackage)
                            }
                        },
                        enabled = manualPackage.contains("."),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add Package to Vault", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search installed games...", color = TextMuted, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkSurfaceBorder
                        ),
                        singleLine = true
                    )

                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = NeonCyan)
                        }
                    } else if (filteredApps.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No installed apps found. Try Manual Package tab.", color = TextMuted, fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(filteredApps) { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onSelectApp(app) }
                                        .background(DarkSurfaceVariant)
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (app.iconBitmap != null) {
                                        Image(
                                            bitmap = app.iconBitmap,
                                            contentDescription = app.appName,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    } else {
                                        Icon(
                                            Icons.Default.SportsEsports,
                                            contentDescription = null,
                                            tint = NeonCyan,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(text = app.appName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                                            if (app.isGameCategory) {
                                                Surface(shape = RoundedCornerShape(4.dp), color = NeonGreen.copy(alpha = 0.2f)) {
                                                    Text("GAME", color = NeonGreen, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                }
                                            }
                                        }
                                        Text(text = app.packageName, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
                                    }

                                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Add", tint = NeonCyan, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun FullGameProfileDialog(
    profile: GameProfile,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)? = null,
    onSave: (GameProfile) -> Unit
) {
    val entitlement by MembershipManager.entitlement.collectAsState()
    var selectedMode by remember { mutableStateOf(profile.performanceMode) }
    var selectedFps by remember { mutableStateOf(profile.fpsLock) }
    var notes by remember { mutableStateOf(profile.customNotes) }
    var proPresetHint by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text("Tune ${profile.name}", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (entitlement.allowProProfileCustomization) {
                                "Pro Quick Profile Presets (Unlocked)"
                            } else {
                                "Pro Quick Profile Presets (Optional Pro)"
                            },
                            color = NeonPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                Triple("Tournament", PerformanceMode.PERFORMANCE_ASSISTANT, 90),
                                Triple("Cool Long Run", PerformanceMode.THERMAL_PROTECTION, 60),
                                Triple("Battery Sync", PerformanceMode.BATTERY_SAVER, 45)
                            ).forEach { (label, presetMode, presetFps) ->
                                FilterChip(
                                    selected = selectedMode == presetMode && selectedFps == presetFps && notes.contains(label),
                                    onClick = {
                                        if (entitlement.allowProProfileCustomization) {
                                            proPresetHint = null
                                            selectedMode = presetMode
                                            selectedFps = presetFps
                                            notes = "[Pro Preset: $label] Target ${presetFps}fps, ${presetMode.displayName}"
                                        } else {
                                            proPresetHint = "Pro presets unlock with GAMEBOOST Pro. Manual tuning below stays free."
                                        }
                                    },
                                    label = { Text(if (entitlement.allowProProfileCustomization) label else "$label ★", fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeonPurple.copy(alpha = 0.2f),
                                        selectedLabelColor = NeonPurple
                                    )
                                )
                            }
                        }
                        if (!proPresetHint.isNullOrBlank()) {
                            Text(text = proPresetHint.orEmpty(), color = NeonPurple, fontSize = 10.sp)
                        }
                    }
                    HorizontalDivider(color = DarkSurfaceBorder, modifier = Modifier.padding(top = 6.dp))
                }

                item {
                    Text("Performance Assistant Mode", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                items(PerformanceMode.values()) { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedMode = mode }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RadioButton(
                            selected = selectedMode == mode,
                            onClick = { selectedMode = mode },
                            colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                        )
                        Column {
                            Text(text = mode.displayName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = mode.description, color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }

                item {
                    HorizontalDivider(color = DarkSurfaceBorder)
                    Text("Target FPS Lock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(30, 45, 60, 90).forEach { fps ->
                            FilterChip(
                                selected = selectedFps == fps,
                                onClick = { selectedFps = fps },
                                label = { Text("$fps FPS") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = NeonCyan
                                )
                            )
                        }
                    }
                }

                item {
                    HorizontalDivider(color = DarkSurfaceBorder)
                    Text("Tactical Notes (Crosshair / Gyro / Recoil)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        placeholder = { Text("e.g. Sensitivity 120%, gyro always on...", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 11.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkSurfaceBorder
                        )
                    )
                }

                if (onDelete != null) {
                    item {
                        OutlinedButton(
                            onClick = onDelete,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonRed)
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, tint = NeonRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete Saved Profile", color = NeonRed, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(profile.copy(performanceMode = selectedMode, fpsLock = selectedFps, customNotes = notes))
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
            ) {
                Text("Save Profile", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
