package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF060911)
val DarkSurface = Color(0xFF0E1525)
val DarkSurfaceVariant = Color(0xFF172238)
val DarkSurfaceBorder = Color(0xFF263552)

val GamingBlue = Color(0xFF2979FF)
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanVariant = Color(0xFF18FFFF)
val NeonGreen = Color(0xFF00E676)
val NeonPurple = Color(0xFFB388FF)
val NeonOrange = Color(0xFFFF9100)
val NeonRed = Color(0xFFFF2E54)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
