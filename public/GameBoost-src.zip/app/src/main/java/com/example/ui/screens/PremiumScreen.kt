package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.billing.BillingConnectionState
import com.example.billing.BillingManager
import com.example.billing.BillingOffer
import com.example.billing.BillingUiState
import com.example.billing.GooglePlayBillingManager
import com.example.billing.PurchaseFlowStatus
import com.example.data.MembershipManager
import com.example.ui.theme.*

@Composable
fun PremiumScreen(
    billingManager: BillingManager = GooglePlayBillingManager
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findBillingActivity() }
    val entitlement by MembershipManager.entitlement.collectAsState()
    val billingState by billingManager.billingState.collectAsState()
    var manageActionError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("premium_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        text = "GAMEBOOST PRO",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                }
                Text(
                    text = "Optional Pro upgrade via Google Play Billing. All core diagnostics, Autopilot, and benchmark tools remain 100% Free.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Verified Subscription / Entitlement Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("premium_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (entitlement.isPremium) DarkSurfaceVariant else DarkSurface
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = "Subscription & Entitlement Status",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = entitlement.tier.title,
                                color = if (entitlement.isPremium) NeonPurple else NeonCyan,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = entitlement.billingStatusMessage,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                entitlement.isPremium -> NeonPurple.copy(alpha = 0.2f)
                                entitlement.isPendingPurchase -> NeonOrange.copy(alpha = 0.2f)
                                else -> NeonCyan.copy(alpha = 0.14f)
                            }
                        ) {
                            Text(
                                text = when {
                                    entitlement.isPremium -> "PRO ACTIVE"
                                    entitlement.isPendingPurchase -> "PENDING"
                                    else -> "FREE TIER"
                                },
                                color = when {
                                    entitlement.isPremium -> NeonPurple
                                    entitlement.isPendingPurchase -> NeonOrange
                                    else -> NeonCyan
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (entitlement.activeProductId != null || billingState.activeTokenFingerprint != null) {
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Plan ID: ${entitlement.activeProductId ?: "None"} • Verification: ${entitlement.verificationSource}",
                                color = TextMuted,
                                fontSize = 10.5.sp
                            )
                            val fp = entitlement.tokenFingerprint ?: billingState.activeTokenFingerprint
                            if (!fp.isNullOrBlank()) {
                                Text(
                                    text = "Verified Token Fingerprint: $fp",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Billing connection / purchase flow status banner
                    BillingFeedbackBanner(billingState = billingState)

                    if (BuildConfig.DEBUG) {
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Debug UI Preview Only (Not Play Billing)",
                                color = TextMuted,
                                fontSize = 10.sp,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(
                                onClick = { MembershipManager.toggleDevPreviewPremium() },
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("premium_debug_preview_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (entitlement.isPremium) NeonGreen else NeonPurple
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (entitlement.isPremium) "Revert Preview" else "Preview Pro UI",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Google Play Subscription Plan Cards (Monthly + Yearly + Optional One-Time)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Google Play Plans",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )

                val catalog = billingState.catalog
                PlanOfferCard(
                    planName = "GAMEBOOST Pro Monthly",
                    productId = catalog.monthlySubscriptionId,
                    offer = billingState.monthlyOffer,
                    subtitle = "Flexible monthly Google Play subscription • Cancel anytime",
                    accentColor = NeonCyan,
                    isCurrentlyActive = entitlement.isPremium && entitlement.activeProductId == catalog.monthlySubscriptionId,
                    isBillingReady = billingState.connectionState == BillingConnectionState.CONNECTED,
                    isPurchaseInProgress = billingState.purchaseStatus is PurchaseFlowStatus.LaunchingCheckout,
                    buttonTag = "premium_subscribe_monthly_button",
                    onSubscribeClick = {
                        activity?.let { billingManager.launchPurchase(it, catalog.monthlySubscriptionId) }
                    }
                )

                PlanOfferCard(
                    planName = "GAMEBOOST Pro Yearly",
                    productId = catalog.yearlySubscriptionId,
                    offer = billingState.yearlyOffer,
                    subtitle = "Annual Google Play subscription • Best long-term value",
                    accentColor = NeonPurple,
                    isCurrentlyActive = entitlement.isPremium && entitlement.activeProductId == catalog.yearlySubscriptionId,
                    isBillingReady = billingState.connectionState == BillingConnectionState.CONNECTED,
                    isPurchaseInProgress = billingState.purchaseStatus is PurchaseFlowStatus.LaunchingCheckout,
                    buttonTag = "premium_subscribe_yearly_button",
                    onSubscribeClick = {
                        activity?.let { billingManager.launchPurchase(it, catalog.yearlySubscriptionId) }
                    }
                )

                billingState.oneTimeOffers.forEach { oneTimeOffer ->
                    PlanOfferCard(
                        planName = oneTimeOffer.title.ifBlank { "GAMEBOOST Pro Pass" },
                        productId = oneTimeOffer.productId,
                        offer = oneTimeOffer,
                        subtitle = "One-time Google Play product • No recurring charges",
                        accentColor = NeonGreen,
                        isCurrentlyActive = entitlement.isPremium && entitlement.activeProductId == oneTimeOffer.productId,
                        isBillingReady = billingState.connectionState == BillingConnectionState.CONNECTED,
                        isPurchaseInProgress = billingState.purchaseStatus is PurchaseFlowStatus.LaunchingCheckout,
                        buttonTag = "premium_subscribe_onetime_${oneTimeOffer.productId}",
                        onSubscribeClick = {
                            activity?.let { billingManager.launchPurchase(it, oneTimeOffer.productId) }
                        }
                    )
                }
            }
        }

        // Restore Purchases & Manage Subscription Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Account & Subscription Controls",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { billingManager.restorePurchases() },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("premium_restore_purchases_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restore Purchases", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    context.startActivity(billingManager.buildManageSubscriptionIntent(context))
                                    manageActionError = null
                                } catch (_: Exception) {
                                    manageActionError = "Google Play Store app not available to open subscriptions page."
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("premium_manage_subscription_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonPurple)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Manage Subscription", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (!manageActionError.isNullOrBlank()) {
                        Text(
                            text = manageActionError.orEmpty(),
                            color = NeonOrange,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }
        }

        // Renewal & Cancellation Disclosure Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                        Text(
                            text = "Renewal, Cancellation & Verification Policy",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = "• Billing & Auto-Renewal: Subscriptions are billed exclusively through your Google Play account and renew automatically unless cancelled at least 24 hours before the end of the current period.\n" +
                            "• Easy Cancellation: Tap 'Manage Subscription' above or open Google Play → Payments & subscriptions anytime. Cancelled plans stay active until the paid period ends.\n" +
                            "• Pending Payments & Refunds: Pending payments unlock Pro only after Google Play confirms payment. Refunded, voided, or expired subscriptions revoke Pro access automatically.\n" +
                            "• Essential Tools Always Free: Hardware telemetry, Network diagnostics, Benchmark Lab, Aim Lab, Game Space, and Autopilot 3.0 remain 100% Free.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Comparison Table Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Free vs Pro Feature Matrix",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Capability / Module", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
                        Text("Free", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("Pro", color = NeonPurple, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    ComparisonRow("Core Hardware Diagnostics", "Included", "Included")
                    ComparisonRow("Gateway Latency & Jitter", "Included", "Included")
                    ComparisonRow("Benchmark Lab & Aim Lab", "Included", "Included")
                    ComparisonRow("Game Space & Autopilot 3.0", "Included", "Included")
                    ComparisonRow("Advertisements", "Home & Reports", "Completely Ad-Free")
                    ComparisonRow("Overlay Themes & Accents", "Cyan Default", "Purple / Green / OLED")
                    ComparisonRow("Game Profile Customization", "3 Core Profiles", "+ Pro Presets & Tags")
                    ComparisonRow("Advanced Session Reports", "Standard", "Efficiency & Export")
                    ComparisonRow("Report History & Compare", "Last 10 Runs", "Extended (50+ Runs)")
                }
            }
        }
    }
}

@Composable
private fun BillingFeedbackBanner(billingState: BillingUiState) {
    val (tint, text) = when (val status = billingState.purchaseStatus) {
        is PurchaseFlowStatus.VerifiedActive -> NeonGreen to status.message
        is PurchaseFlowStatus.Pending -> NeonOrange to status.message
        is PurchaseFlowStatus.Cancelled -> TextSecondary to status.message
        is PurchaseFlowStatus.Failed -> NeonRed to status.message
        is PurchaseFlowStatus.Restoring -> NeonCyan to "Restoring purchases from Google Play..."
        is PurchaseFlowStatus.LaunchingCheckout -> NeonCyan to "Opening Google Play checkout for ${status.productId}..."
        PurchaseFlowStatus.Connecting -> NeonCyan to "Connecting to Google Play Billing..."
        PurchaseFlowStatus.Idle -> when (billingState.connectionState) {
            BillingConnectionState.CONNECTED -> NeonGreen to billingState.statusBannerMessage
            BillingConnectionState.CONNECTING -> NeonCyan to billingState.statusBannerMessage
            BillingConnectionState.DISCONNECTED,
            BillingConnectionState.SERVICE_UNAVAILABLE -> TextMuted to billingState.statusBannerMessage
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("premium_billing_feedback_banner"),
        shape = RoundedCornerShape(10.dp),
        color = tint.copy(alpha = 0.1f)
    ) {
        Text(
            text = text,
            color = tint,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun PlanOfferCard(
    planName: String,
    productId: String,
    offer: BillingOffer?,
    subtitle: String,
    accentColor: Color,
    isCurrentlyActive: Boolean,
    isBillingReady: Boolean,
    isPurchaseInProgress: Boolean,
    buttonTag: String,
    onSubscribeClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isCurrentlyActive) Modifier.border(1.5.dp, accentColor, RoundedCornerShape(16.dp))
                else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = planName,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = subtitle,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "SKU: $productId",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    if (offer != null && offer.isAvailableInPlayStore) {
                        Text(
                            text = offer.formattedPrice,
                            color = accentColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = offer.billingPeriodLabel,
                            color = TextSecondary,
                            fontSize = 10.5.sp
                        )
                    } else {
                        Text(
                            text = "Price Pending",
                            color = TextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Play Store SKU",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            if (offer?.introSummary != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = accentColor.copy(alpha = 0.14f)
                ) {
                    Text(
                        text = offer.introSummary,
                        color = accentColor,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            val canTapPurchase = !isCurrentlyActive && !isPurchaseInProgress && isBillingReady && offer != null
            Button(
                onClick = onSubscribeClick,
                enabled = canTapPurchase,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag(buttonTag),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.Black,
                    disabledContainerColor = DarkSurfaceVariant,
                    disabledContentColor = TextMuted
                )
            ) {
                Text(
                    text = when {
                        isCurrentlyActive -> "Active Plan"
                        isPurchaseInProgress -> "Processing..."
                        offer == null -> "Awaiting Google Play Product Price"
                        !isBillingReady -> "Google Play Not Connected"
                        else -> "Subscribe (${offer.formattedPrice} ${offer.billingPeriodLabel})"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ComparisonRow(feature: String, free: String, pro: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(feature, color = TextPrimary, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
        Text(free, color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
        Text(pro, color = NeonPurple, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, modifier = Modifier.weight(1f))
    }
}

private tailrec fun Context.findBillingActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findBillingActivity()
    else -> null
}
