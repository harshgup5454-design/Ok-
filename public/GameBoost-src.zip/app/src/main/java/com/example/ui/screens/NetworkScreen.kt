package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkHistoryRecord
import com.example.data.NetworkStats
import com.example.data.ProtectionSeverity
import com.example.ui.theme.*
import com.example.ads.*
import com.example.ui.components.AdMobAdaptiveBannerSlot

import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.automirrored.filled.ArrowBack

@Composable
fun NetworkScreen(
    stats: NetworkStats,
    isSpeedTesting: Boolean,
    speedTestProgress: Float,
    networkHistory: List<NetworkHistoryRecord>,
    onTestPing: () -> Unit,
    onStartSpeedTest: () -> Unit,
    onCancelSpeedTest: () -> Unit,
    onClearHistory: () -> Unit = {},
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onBackClick: (() -> Unit)? = null
) {
    if (onBackClick != null) {
        BackHandler { onBackClick() }
    }

    val adState by adManager.adState.collectAsState()
    val networkVisibility = AdVisibilityContext(
        location = AdScreenLocation.NETWORK_TOOLS,
        isGamingSessionActive = isAutopilotActive,
        isAutopilotSessionActive = isAutopilotActive,
        isSpeedTesting = isSpeedTesting,
        thermalSeverity = thermalSeverity
    )
    val shouldShowNetworkBanner = !isPremium && remember(adState, networkVisibility) {
        adManager.canDisplayAds(networkVisibility)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (shouldShowNetworkBanner) {
            item {
                AdMobAdaptiveBannerSlot(
                    visibilityContext = networkVisibility,
                    adManager = adManager,
                    testTagName = "network_tools_ad_banner_slot"
                )
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBackClick != null) {
                        IconButton(onClick = onBackClick, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                        }
                    }
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(24.dp))
                    Text(
                        text = "NETWORK INTELLIGENCE",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.0.sp
                    )
                }
                Text(
                    text = "Gateway ping, RFC 3393 jitter variance, and internet speed diagnostics.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Connection Status & Diagnostics Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (stats.connectionType) {
                                    "Wi-Fi" -> Icons.Default.Wifi
                                    "Ethernet" -> Icons.Default.SettingsEthernet
                                    "Offline" -> Icons.Default.CloudOff
                                    else -> Icons.Default.SignalCellularAlt
                                },
                                contentDescription = null,
                                tint = if (stats.isConnected) NeonCyan else NeonRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "Connection Dashboard",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (stats.isConnected) NeonGreen.copy(alpha = 0.15f) else NeonRed.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (stats.isConnected) stats.connectionType.uppercase() else "OFFLINE",
                                color = if (stats.isConnected) NeonGreen else NeonRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    // Metrics Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NetworkMetricBox(
                            modifier = Modifier.weight(1f),
                            title = "Gateway Latency",
                            value = if (stats.pingMs < 0) "Not Tested" else "${stats.pingMs} ms",
                            sub = buildString {
                                if (stats.minPingMs > 0) append("Min ${stats.minPingMs} • Max ${stats.maxPingMs}") else append("8.8.8.8:53")
                                if (stats.secondaryPingMs > 0) append(" • Alt ${stats.secondaryPingMs}ms")
                            },
                            tint = when {
                                stats.pingMs < 0 -> TextMuted
                                stats.pingMs < 50 -> NeonGreen
                                stats.pingMs < 100 -> NeonOrange
                                else -> NeonRed
                            }
                        )
                        NetworkMetricBox(
                            modifier = Modifier.weight(1f),
                            title = "Latency Jitter",
                            value = if (stats.pingMs < 0) "—" else "${stats.jitterMs} ms",
                            sub = "RFC 3393 Delay Var",
                            tint = if (stats.jitterMs <= 15) NeonGreen else NeonOrange
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NetworkMetricBox(
                            modifier = Modifier.weight(1f),
                            title = "DNS Resolution",
                            value = if (stats.dnsResolutionMs < 0) "—" else "${stats.dnsResolutionMs} ms",
                            sub = "dns.google lookup",
                            tint = NeonCyan
                        )
                        NetworkMetricBox(
                            modifier = Modifier.weight(1f),
                            title = "Packet Loss / Timeouts",
                            value = "${stats.packetLossPercent}%",
                            sub = "${stats.timeoutCount} timeouts recorded",
                            tint = if (stats.packetLossPercent == 0) NeonGreen else NeonRed
                        )
                    }

                    Button(
                        onClick = onTestPing,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Run Advanced Gateway Diagnostics", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Speed Test Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
                            Text(text = "Internet Speed Benchmark", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NeonOrange.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "USES INTERNET DATA",
                                color = NeonOrange,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "HTTP Download Probe", color = TextSecondary, fontSize = 11.sp)
                            Text(text = "${stats.downloadSpeedMbps} Mbps", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Link Upstream Est.", color = TextSecondary, fontSize = 11.sp)
                            Text(text = "${stats.uploadSpeedMbps} Mbps", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    Text(
                        text = stats.throughputNote,
                        color = TextMuted,
                        fontSize = 10.5.sp,
                        lineHeight = 14.sp
                    )

                    if (isSpeedTesting) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            LinearProgressIndicator(
                                progress = { speedTestProgress },
                                modifier = Modifier.fillMaxWidth(),
                                color = NeonGreen,
                                trackColor = DarkSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Testing bandwidth (${(speedTestProgress * 100).toInt()}%)...", color = TextSecondary, fontSize = 11.sp)
                                TextButton(onClick = onCancelSpeedTest) {
                                    Text(text = "Cancel", color = NeonRed, fontSize = 11.sp)
                                }
                            }
                        }
                    } else {
                        Button(
                            onClick = onStartSpeedTest,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Start Speed Test Benchmark", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Network Advisor & Multiplayer Explanation
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                        Text(text = "Network Advisor & Multiplayer Guidance", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(
                        text = "• Connection Type: ${stats.connectionType}. If playing on crowded public Wi-Fi, interference from other routers can spike jitter.\n• Manual Switching: If mobile data provides lower ping than unstable Wi-Fi, switch manually via system settings.\n• Multiplayer Desync: Packet loss (>5%) causes rubberbanding and hit-reg delay in fast-paced combat games.\n• Gateway Measurement: Gateway ping measures your connection to your internet service provider's backbone router, not specific game servers.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Historical Records
        if (networkHistory.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Network Test History (${networkHistory.size})", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    TextButton(onClick = onClearHistory) {
                        Text("Clear", color = NeonRed, fontSize = 11.sp)
                    }
                }
            }
            items(networkHistory) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = record.connectionType, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "${record.avgPingMs} ms • Jitter: ${record.jitterMs}ms", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text(text = record.rating, color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkMetricBox(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    sub: String,
    tint: Color
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(text = title, color = TextSecondary, fontSize = 11.sp)
            Text(text = value, color = tint, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text = sub, color = TextMuted, fontSize = 10.sp)
        }
    }
}
