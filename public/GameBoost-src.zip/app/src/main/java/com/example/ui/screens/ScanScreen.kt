package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticItem
import com.example.viewmodel.DiagnosticStatus
import com.example.ads.*
import com.example.ui.components.AdMobAdaptiveBannerSlot
import kotlin.math.hypot

import androidx.activity.compose.BackHandler

@Composable
fun ScanScreen(
    isScanning: Boolean,
    results: List<DiagnosticItem>,
    bottleneckAnalysis: BottleneckAnalysis?,
    checklist: List<PreGameChecklistItem>,
    storageData: StorageDiagnosticData?,
    displayData: DisplayDiagnosticData?,
    batteryData: BatteryDiagnosticData?,
    systemData: SystemCompatibilityData?,
    diagnosticReport: DeviceDiagnosticReport?,
    edgeResponseState: EdgeResponseState,
    lastSwipeResult: SwipeMetricResult?,
    onToggleChecklistItem: (String) -> Unit,
    onStartScan: () -> Unit,
    onRecordSwipe: (SwipeMetricResult) -> Unit,
    onRecordEdgeHit: (String) -> Unit,
    onResetEdgeTests: () -> Unit,
    onClearAppCache: () -> Unit,
    onRefreshDiagnostics: () -> Unit,
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onBackClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0=Scanner, 1=Storage, 2=Touchscreen, 3=Display & Battery, 4=System & Report

    if (onBackClick != null) {
        BackHandler { onBackClick() }
    }

    LaunchedEffect(Unit) {
        onRefreshDiagnostics()
    }

    val adState by adManager.adState.collectAsState()
    val scanVisibility = AdVisibilityContext(
        location = AdScreenLocation.DEVICE_DIAGNOSTICS,
        isGamingSessionActive = isAutopilotActive,
        isAutopilotSessionActive = isAutopilotActive,
        isScanning = isScanning,
        thermalSeverity = thermalSeverity
    )
    val shouldShowScanBanner = !isPremium && remember(adState, scanVisibility) {
        adManager.canDisplayAds(scanVisibility)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (shouldShowScanBanner) {
            item {
                AdMobAdaptiveBannerSlot(
                    visibilityContext = scanVisibility,
                    adManager = adManager,
                    testTagName = "device_diagnostics_ad_banner_slot"
                )
            }
        }

        // Section Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onBackClick != null) {
                            IconButton(onClick = onBackClick, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                            }
                        }
                        Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "DIAGNOSTICS LAB",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                    }

                    IconButton(
                        onClick = onRefreshDiagnostics,
                        colors = IconButtonDefaults.iconButtonColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = NeonCyan)
                    }
                }
                Text(
                    text = "Hardware diagnostics, storage analyzer, touchscreen tester, and compatibility reports.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Sub-Navigation Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = NeonCyan,
                edgePadding = 0.dp,
                divider = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Scanner", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Storage", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Touchscreen", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Display & Battery", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("System & Report", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        // TAB CONTENT
        when (selectedTab) {
            0 -> {
                // ==========================================
                // TAB 0: HARDWARE SCANNER & ASSISTANT (ORIGINAL PRESERVED)
                // ==========================================
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(36.dp))
                                    .background(DarkSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isScanning) {
                                    CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(36.dp))
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (isScanning) "Inspecting System Telemetry..." else if (results.isNotEmpty()) "Diagnostics Complete" else "Ready to Analyze Hardware",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tests PowerManager thermal headroom, RAM pressure, and TCP socket jitter.",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            }

                            Button(
                                onClick = onStartScan,
                                enabled = !isScanning,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isScanning) "Analyzing Hardware..." else "Start Performance Scan",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Bottleneck Analysis Strategy Card
                if (bottleneckAnalysis != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Analytics, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "Limiter Analysis: ${bottleneckAnalysis.primaryBottleneck.title}",
                                        color = Color(bottleneckAnalysis.primaryBottleneck.badgeColorHex),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }

                                Text(
                                    text = bottleneckAnalysis.technicalCause,
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp
                                )

                                HorizontalDivider(color = DarkSurfaceBorder)

                                Text(
                                    text = "Conditional Strategy:",
                                    color = NeonGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )

                                Text(
                                    text = bottleneckAnalysis.conditionalStrategy,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                // Pre-Game Preparation Checklist Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Checklist, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                                    Text(text = "Pre-Game Preparation Checklist", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }

                                Text(
                                    text = "${checklist.count { it.isCompleted }}/${checklist.size}",
                                    color = NeonGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Text(
                                text = "Real device optimizations that directly stop thermal throttling and frame drops:",
                                color = TextMuted,
                                fontSize = 12.sp
                            )

                            checklist.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Checkbox(
                                        checked = item.isCompleted,
                                        onCheckedChange = { onToggleChecklistItem(item.id) },
                                        colors = CheckboxDefaults.colors(checkedColor = NeonCyan)
                                    )
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(text = item.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = item.whyItMayHelp, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                                    }
                                }
                            }

                            HorizontalDivider(color = DarkSurfaceBorder)
                            Text(text = "Android System Shortcuts:", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        try {
                                            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                                        } catch (_: Exception) {
                                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(text = "DND Setup", fontSize = 11.sp, color = NeonCyan)
                                }

                                OutlinedButton(
                                    onClick = {
                                        try {
                                            context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                                        } catch (_: Exception) {
                                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(text = "Display (60Hz)", fontSize = 11.sp, color = NeonCyan)
                                }

                                OutlinedButton(
                                    onClick = {
                                        try {
                                            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                                        } catch (_: Exception) {
                                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(text = "Battery", fontSize = 11.sp, color = NeonCyan)
                                }
                            }
                        }
                    }
                }

                // Diagnostic Findings
                if (results.isNotEmpty()) {
                    item {
                        Text(
                            text = "Hardware Telemetry Findings",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    items(results) { item ->
                        DiagnosticResultCard(item = item)
                    }
                }
            }

            1 -> {
                // ==========================================
                // TAB 1: STORAGE ANALYZER
                // ==========================================
                item {
                    val storage = storageData
                    if (storage != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            // Storage Overview Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Storage, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                                            Text("Internal Storage Overview", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        }
                                        Text("${storage.usagePercent}% Used", color = if (storage.usagePercent > 88) NeonOrange else NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }

                                    LinearProgressIndicator(
                                        progress = { storage.usagePercent / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(10.dp)
                                            .clip(RoundedCornerShape(5.dp)),
                                        color = if (storage.usagePercent > 88) NeonOrange else NeonCyan,
                                        trackColor = DarkSurfaceBorder
                                    )

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${storage.usedInternalGb} GB Used", color = TextSecondary, fontSize = 12.sp)
                                        Text("${storage.availableInternalGb} GB Free", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("${storage.totalInternalGb} GB Total", color = TextSecondary, fontSize = 12.sp)
                                    }
                                }
                            }

                            // App-Accessible Footprint Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("GAMEBOOST Accessible Footprint", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Internal Cache:", color = TextSecondary, fontSize = 12.sp)
                                        Text(DeviceDiagnosticsEngine.formatBytes(storage.appInternalCacheBytes), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("External Cache:", color = TextSecondary, fontSize = 12.sp)
                                        Text(DeviceDiagnosticsEngine.formatBytes(storage.appExternalCacheBytes), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("App Database & Files:", color = TextSecondary, fontSize = 12.sp)
                                        Text(DeviceDiagnosticsEngine.formatBytes(storage.appFilesBytes), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    HorizontalDivider(color = DarkSurfaceBorder)

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Total App Footprint:", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(storage.totalAppFootprintFormatted, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                onClearAppCache()
                                                Toast.makeText(context, "App cache cleared safely", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.2f)),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = NeonRed, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Clear App Cache", color = NeonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                try {
                                                    context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
                                                } catch (_: Exception) {
                                                    context.startActivity(Intent(Settings.ACTION_SETTINGS))
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("System Storage", color = NeonCyan, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            // Largest Accessible Files List
                            if (storage.largestAccessibleFiles.isNotEmpty()) {
                                Text("Largest Accessible Files in Sandbox", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                storage.largestAccessibleFiles.forEach { file ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(file.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                Text(file.directoryCategory, color = TextSecondary, fontSize = 11.sp)
                                            }
                                            Text(file.sizeFormatted, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            // Safe Cleanup Guidance Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = storage.cleanupGuidance,
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    } else {
                        CircularProgressIndicator(color = NeonCyan)
                    }
                }
            }

            2 -> {
                // ==========================================
                // TAB 2: TOUCHSCREEN TEST LAB
                // ==========================================
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Interactive Touchscreen Test Canvas", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "Test multi-touch points, screen-edge sensitivity, and swipe latency within GAMEBOOST.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )

                        // Interactive Multi-touch Canvas
                        TouchTestCanvas(
                            edgeState = edgeResponseState,
                            onRecordSwipe = onRecordSwipe,
                            onRecordEdgeHit = onRecordEdgeHit
                        )

                        // Edge Response Status Grid
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Screen-Edge Response Verification", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    TextButton(onClick = onResetEdgeTests) {
                                        Text("Reset", color = NeonCyan, fontSize = 11.sp)
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    EdgeStatusBadge(modifier = Modifier.weight(1f), label = "Left Edge", passed = edgeResponseState.leftEdgeHit)
                                    EdgeStatusBadge(modifier = Modifier.weight(1f), label = "Right Edge", passed = edgeResponseState.rightEdgeHit)
                                    EdgeStatusBadge(modifier = Modifier.weight(1f), label = "Top Edge", passed = edgeResponseState.topEdgeHit)
                                    EdgeStatusBadge(modifier = Modifier.weight(1f), label = "Bottom Edge", passed = edgeResponseState.bottomEdgeHit)
                                }

                                Text(
                                    text = if (edgeResponseState.allEdgesTested)
                                        "All 4 display edges respond to touch inputs. Edge gestures & sidebar triggers will operate reliably."
                                    else
                                        "Touch each glowing edge boundary inside the canvas above to confirm touch sensor registration up to the bezel.",
                                    color = if (edgeResponseState.allEdgesTested) NeonGreen else TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Last Swipe Result Metrics Card
                        if (lastSwipeResult != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Last Measured Swipe Telemetry", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Distance:", color = TextSecondary, fontSize = 12.sp)
                                        Text("${lastSwipeResult.distancePx.toInt()} px", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Duration:", color = TextSecondary, fontSize = 12.sp)
                                        Text("${lastSwipeResult.durationMs} ms", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Velocity:", color = TextSecondary, fontSize = 12.sp)
                                        Text("${lastSwipeResult.velocityPxPerSec.toInt()} px/sec", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Touch Interruption:", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (lastSwipeResult.wasInterrupted) "Interrupted" else "Clean Event", color = if (lastSwipeResult.wasInterrupted) NeonOrange else NeonGreen, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // ==========================================
                // TAB 3: DISPLAY & BATTERY ANALYZER
                // ==========================================
                item {
                    val display = displayData
                    val battery = batteryData

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        // Display Diagnostics Card
                        if (display != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.DisplaySettings, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                                            Text("Display Panel Telemetry", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        }
                                        Surface(shape = RoundedCornerShape(6.dp), color = NeonGreen.copy(alpha = 0.15f)) {
                                            Text("${display.currentRefreshRateHz.toInt()} Hz Active", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Resolution (Physical):", color = TextSecondary, fontSize = 12.sp)
                                        Text(display.resolutionPx, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Resolution (Layout):", color = TextSecondary, fontSize = 12.sp)
                                        Text(display.resolutionDp, color = TextPrimary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Density Scale / DPI:", color = TextSecondary, fontSize = 12.sp)
                                        Text("${display.densityDpi} DPI (${display.densityCategory})", color = TextPrimary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Color Gamut & HDR:", color = TextSecondary, fontSize = 12.sp)
                                        Text(display.hdrTypes, color = TextPrimary, fontSize = 12.sp)
                                    }

                                    HorizontalDivider(color = DarkSurfaceBorder)

                                    Text("Supported Hardware Refresh Modes:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        display.supportedModes.take(4).forEach { mode ->
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = DarkSurfaceVariant,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text("${mode.refreshRateHz.toInt()} Hz", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                    Text("${mode.widthPx}p", color = TextSecondary, fontSize = 10.sp)
                                                }
                                            }
                                        }
                                    }

                                    // Educational Banner
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = DarkSurfaceVariant
                                    ) {
                                        Text(
                                            text = display.educationalNote,
                                            color = TextSecondary,
                                            fontSize = 11.sp,
                                            lineHeight = 15.sp,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Battery Diagnostics Card
                        if (battery != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
                                            Text("Battery Telemetry", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        }
                                        Text("${battery.levelPercent}%", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Power State:", color = TextSecondary, fontSize = 12.sp)
                                        Text("${battery.status} (${battery.powerSource})", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Sensor Temperature:", color = TextSecondary, fontSize = 12.sp)
                                        val hasTemp = battery.temperatureC > 0f
                                        Text(
                                            text = if (hasTemp) "${battery.temperatureC}°C" else "N/A",
                                            color = if (!hasTemp) TextSecondary else if (battery.temperatureC >= 40f) NeonRed else NeonGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Measured Voltage:", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (battery.voltageVolts != null) "${battery.voltageVolts} V" else "Unavailable", color = TextPrimary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Instantaneous Current:", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (battery.currentMilliAmperes != null) "${battery.currentMilliAmperes} mA" else "Unsupported by OEM driver", color = TextPrimary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Health Category:", color = TextSecondary, fontSize = 12.sp)
                                        Text(battery.healthCategory, color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }

                                    HorizontalDivider(color = DarkSurfaceBorder)

                                    Text(
                                        text = battery.healthDisclaimer,
                                        color = TextMuted,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            4 -> {
                // ==========================================
                // TAB 4: SYSTEM COMPATIBILITY & EXPORTABLE REPORT
                // ==========================================
                item {
                    val system = systemData
                    val report = diagnosticReport

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        // System Compatibility Card
                        if (system != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Android Platform Compatibility", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Android Version & SDK:", color = TextSecondary, fontSize = 12.sp)
                                        Text("Android ${system.androidVersion} (API ${system.sdkInt})", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Security Patch:", color = TextSecondary, fontSize = 12.sp)
                                        Text(system.securityPatch, color = TextPrimary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("PowerManager Thermal API:", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (system.thermalStatusApiAvailable) "Supported" else "Unsupported", color = if (system.thermalStatusApiAvailable) NeonGreen else NeonOrange, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Thermal Headroom API:", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (system.thermalHeadroomApiAvailable) "Supported (API 30+)" else "Unsupported", color = if (system.thermalHeadroomApiAvailable) NeonGreen else TextSecondary, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Overlay (SYSTEM_ALERT_WINDOW):", color = TextSecondary, fontSize = 12.sp)
                                        Text(if (system.overlayPermissionGranted) "Granted" else "Requires Permission", color = if (system.overlayPermissionGranted) NeonGreen else NeonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }

                                    if (!system.overlayPermissionGranted) {
                                        Button(
                                            onClick = {
                                                try {
                                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                                                } catch (_: Exception) {
                                                    context.startActivity(Intent(Settings.ACTION_SETTINGS))
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Grant Overlay Permission", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }

                                    HorizontalDivider(color = DarkSurfaceBorder)
                                    Text(system.sandboxExplanations, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                                }
                            }
                        }

                        // Exportable Report Card
                        if (report != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Complete Diagnostic Report", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            IconButton(
                                                onClick = {
                                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                    clipboard.setPrimaryClip(ClipData.newPlainText("GAMEBOOST Report", report.exportableText))
                                                    Toast.makeText(context, "Report copied to clipboard", Toast.LENGTH_SHORT).show()
                                                }
                                            ) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = NeonCyan)
                                            }
                                            IconButton(
                                                onClick = {
                                                    val sendIntent = Intent().apply {
                                                        action = Intent.ACTION_SEND
                                                        putExtra(Intent.EXTRA_TEXT, report.exportableText)
                                                        type = "text/plain"
                                                    }
                                                    try {
                                                        context.startActivity(Intent.createChooser(sendIntent, "Share Diagnostic Report"))
                                                    } catch (_: Exception) {
                                                        Toast.makeText(context, "No compatible share app found", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            ) {
                                                Icon(Icons.Default.Share, contentDescription = "Share", tint = NeonCyan)
                                            }
                                        }
                                    }

                                    Text(report.storageSummary, color = TextSecondary, fontSize = 12.sp)
                                    Text(report.displaySummary, color = TextSecondary, fontSize = 12.sp)
                                    Text(report.batterySummary, color = TextSecondary, fontSize = 12.sp)
                                    Text(report.thermalSummary, color = TextSecondary, fontSize = 12.sp)

                                    HorizontalDivider(color = DarkSurfaceBorder)

                                    Text("Recommended Actions:", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    report.recommendedActions.forEach { act ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("•", color = NeonCyan)
                                            Text(act, color = TextPrimary, fontSize = 12.sp, lineHeight = 16.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EdgeStatusBadge(modifier: Modifier = Modifier, label: String, passed: Boolean) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = if (passed) NeonGreen.copy(alpha = 0.15f) else DarkSurfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (passed) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = if (passed) NeonGreen else TextMuted,
                modifier = Modifier.size(16.dp)
            )
            Text(label, color = if (passed) NeonGreen else TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TouchTestCanvas(
    edgeState: EdgeResponseState,
    onRecordSwipe: (SwipeMetricResult) -> Unit,
    onRecordEdgeHit: (String) -> Unit
) {
    var touchPositions by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var activePointerCount by remember { mutableIntStateOf(0) }
    var swipeStartTime by remember { mutableLongStateOf(0L) }
    var swipeStartPos by remember { mutableStateOf<Offset?>(null) }
    var totalSwipeDist by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurfaceVariant)
            .border(2.dp, if (edgeState.allEdgesTested) NeonGreen else DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        swipeStartTime = System.currentTimeMillis()
                        swipeStartPos = offset
                        totalSwipeDist = 0f
                        touchPositions = listOf(offset)
                        activePointerCount = 1

                        // Check edge hits on touch start
                        val edgeThreshold = 36f
                        if (offset.x <= edgeThreshold) onRecordEdgeHit("left")
                        if (offset.x >= size.width - edgeThreshold) onRecordEdgeHit("right")
                        if (offset.y <= edgeThreshold) onRecordEdgeHit("top")
                        if (offset.y >= size.height - edgeThreshold) onRecordEdgeHit("bottom")
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        touchPositions = listOf(change.position)
                        totalSwipeDist += hypot(dragAmount.x, dragAmount.y)

                        // Check edge hits on drag
                        val edgeThreshold = 36f
                        if (change.position.x <= edgeThreshold) onRecordEdgeHit("left")
                        if (change.position.x >= size.width - edgeThreshold) onRecordEdgeHit("right")
                        if (change.position.y <= edgeThreshold) onRecordEdgeHit("top")
                        if (change.position.y >= size.height - edgeThreshold) onRecordEdgeHit("bottom")
                    },
                    onDragEnd = {
                        val duration = (System.currentTimeMillis() - swipeStartTime).coerceAtLeast(1L)
                        val velocity = (totalSwipeDist / (duration.toFloat() / 1000f))
                        onRecordSwipe(
                            SwipeMetricResult(
                                distancePx = totalSwipeDist,
                                durationMs = duration,
                                velocityPxPerSec = velocity,
                                wasInterrupted = false
                            )
                        )
                        touchPositions = emptyList()
                        activePointerCount = 0
                    },
                    onDragCancel = {
                        val duration = (System.currentTimeMillis() - swipeStartTime).coerceAtLeast(1L)
                        onRecordSwipe(
                            SwipeMetricResult(
                                distancePx = totalSwipeDist,
                                durationMs = duration,
                                velocityPxPerSec = 0f,
                                wasInterrupted = true
                            )
                        )
                        touchPositions = emptyList()
                        activePointerCount = 0
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Draw Edge Target Zones
            val edgeThickness = 24.dp.toPx()
            // Left Edge
            drawRect(
                color = if (edgeState.leftEdgeHit) NeonGreen.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.15f),
                topLeft = Offset(0f, 0f),
                size = androidx.compose.ui.geometry.Size(edgeThickness, h)
            )
            // Right Edge
            drawRect(
                color = if (edgeState.rightEdgeHit) NeonGreen.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.15f),
                topLeft = Offset(w - edgeThickness, 0f),
                size = androidx.compose.ui.geometry.Size(edgeThickness, h)
            )
            // Top Edge
            drawRect(
                color = if (edgeState.topEdgeHit) NeonGreen.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.15f),
                topLeft = Offset(0f, 0f),
                size = androidx.compose.ui.geometry.Size(w, edgeThickness)
            )
            // Bottom Edge
            drawRect(
                color = if (edgeState.bottomEdgeHit) NeonGreen.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.15f),
                topLeft = Offset(0f, h - edgeThickness),
                size = androidx.compose.ui.geometry.Size(w, edgeThickness)
            )

            // Draw Grid Lines
            val gridStep = 40.dp.toPx()
            var x = gridStep
            while (x < w) {
                drawLine(color = DarkSurfaceBorder.copy(alpha = 0.4f), start = Offset(x, 0f), end = Offset(x, h), strokeWidth = 1f)
                x += gridStep
            }
            var y = gridStep
            while (y < h) {
                drawLine(color = DarkSurfaceBorder.copy(alpha = 0.4f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
                y += gridStep
            }

            // Draw Touch Indicator Circles
            touchPositions.forEach { pos ->
                // Outer ring
                drawCircle(color = NeonCyan.copy(alpha = 0.35f), radius = 48.dp.toPx(), center = pos)
                // Middle ring
                drawCircle(color = NeonCyan, radius = 24.dp.toPx(), center = pos, style = Stroke(width = 3.dp.toPx()))
                // Inner core
                drawCircle(color = Color.White, radius = 6.dp.toPx(), center = pos)
                // Crosshair
                drawLine(color = NeonCyan, start = Offset(pos.x - 32.dp.toPx(), pos.y), end = Offset(pos.x + 32.dp.toPx(), pos.y), strokeWidth = 1.5f)
                drawLine(color = NeonCyan, start = Offset(pos.x, pos.y - 32.dp.toPx()), end = Offset(pos.x, pos.y + 32.dp.toPx()), strokeWidth = 1.5f)
            }
        }

        // Live HUD overlay inside canvas
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurface.copy(alpha = 0.85f)
            ) {
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Text(
                        text = if (touchPositions.isNotEmpty())
                            "X: ${touchPositions[0].x.toInt()} px | Y: ${touchPositions[0].y.toInt()} px"
                        else
                            "Touch or drag across canvas to test",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Edges Registered: ${listOf(edgeState.leftEdgeHit, edgeState.rightEdgeHit, edgeState.topEdgeHit, edgeState.bottomEdgeHit).count { it }}/4",
                        color = if (edgeState.allEdgesTested) NeonGreen else TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun DiagnosticResultCard(item: DiagnosticItem) {
    val (color, icon) = when (item.status) {
        DiagnosticStatus.GOOD -> NeonGreen to Icons.Default.CheckCircle
        DiagnosticStatus.WARNING -> NeonOrange to Icons.Default.Warning
        DiagnosticStatus.CRITICAL -> NeonRed to Icons.Default.Error
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(26.dp)
            )

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = item.description,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
