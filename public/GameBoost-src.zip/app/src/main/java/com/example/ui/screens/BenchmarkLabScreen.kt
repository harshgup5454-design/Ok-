package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.ads.*
import com.example.ui.components.AdMobAdaptiveBannerSlot
import java.text.SimpleDateFormat
import java.util.*

import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.automirrored.filled.ArrowBack

@Composable
fun BenchmarkLabScreen(
    labResults: List<BenchmarkLabRunResult>,
    isLabRunning: Boolean,
    labProgress: Float,
    activeWorkload: String,
    telemetryTemp: Float,
    telemetryThermal: String,
    isPremium: Boolean = false,
    isAutopilotActive: Boolean = false,
    thermalSeverity: ProtectionSeverity = ProtectionSeverity.SAFE,
    adManager: AdManager = GoogleAdMobManager,
    onRunWorkload: (Context, WorkloadType) -> Unit,
    onCancelLab: () -> Unit,
    onClearHistory: () -> Unit,
    onBackClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault()) }

    if (onBackClick != null) {
        BackHandler { onBackClick() }
    }

    val adState by adManager.adState.collectAsState()
    val labVisibility = AdVisibilityContext(
        location = AdScreenLocation.BENCHMARK_LAB,
        isGamingSessionActive = isAutopilotActive || isLabRunning,
        isAutopilotSessionActive = isAutopilotActive,
        isBenchmarking = isLabRunning,
        isLabRunning = isLabRunning,
        thermalSeverity = thermalSeverity
    )
    val shouldShowLabBanner = !isPremium && remember(adState, labVisibility) {
        adManager.canDisplayAds(labVisibility)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (shouldShowLabBanner) {
            item {
                AdMobAdaptiveBannerSlot(
                    visibilityContext = labVisibility,
                    adManager = adManager,
                    testTagName = "benchmark_lab_ad_banner_slot"
                )
            }
        }

        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBackClick != null) {
                        IconButton(onClick = onBackClick, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeonCyan)
                        }
                    }
                    Icon(Icons.Default.Speed, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(24.dp))
                    Text(
                        text = "BENCHMARK LAB",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.0.sp
                    )
                }
                Text(
                    text = "Controlled CPU, Memory & App Canvas Workloads with Thermal Safety",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Disclaimer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Scientific Benchmark Integrity",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Workloads measure GAMEBOOST's own internal computing and UI rendering. Results reflect device capability under controlled conditions and do not represent external game frame rates.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Active Lab Run Card if running
        if (isLabRunning) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Running: $activeWorkload",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Button(
                                onClick = onCancelLab,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.2f)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text("Cancel", color = NeonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        LinearProgressIndicator(
                            progress = { labProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = NeonCyan,
                            trackColor = DarkSurfaceBorder
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Battery Temp: ${if (telemetryTemp > 0f) "${telemetryTemp}°C" else "N/A"}",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(text = "Thermal Status: $telemetryThermal", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Workload Selectors
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "Select Benchmark Workload", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                WorkloadType.values().forEach { workload ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(text = workload.displayName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = workload.description, color = TextSecondary, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onRunWorkload(context, workload) },
                                enabled = !isLabRunning,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text("Run", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // History Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Benchmark History (${labResults.size})", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                if (labResults.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) {
                        Text("Clear History", color = NeonRed, fontSize = 12.sp)
                    }
                }
            }
        }

        if (labResults.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "No benchmark results recorded yet.", color = TextSecondary, fontSize = 13.sp)
                }
            }
        } else {
            items(labResults, key = { it.id }) { result ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = result.workloadType, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = dateFormat.format(Date(result.timestamp)), color = TextSecondary, fontSize = 10.sp)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (result.workloadType.contains("CPU")) "Throughput: ${String.format(Locale.US, "%.1f", result.scoreOrOpsPerSec / 1000.0)}k ops/s"
                                else if (result.workloadType.contains("Memory")) "Bandwidth: ${String.format(Locale.US, "%.1f", result.scoreOrOpsPerSec)} MB/s"
                                else "App Render: ~${String.format(Locale.US, "%.1f", result.scoreOrOpsPerSec)} FPS",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(text = "${result.durationMs} ms", color = TextSecondary, fontSize = 11.sp)
                        }

                        HorizontalDivider(color = DarkSurfaceBorder)

                        Text(text = result.detailsSummary, color = TextSecondary, fontSize = 11.sp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val tempLabel = if (result.startBatteryTempC > 0f && result.peakBatteryTempC > 0f) {
                                "${result.startBatteryTempC}°C → ${result.peakBatteryTempC}°C"
                            } else {
                                "N/A"
                            }
                            Text(text = "Battery Temp: $tempLabel", color = TextSecondary, fontSize = 10.sp)
                            Text(text = result.deviceModel, color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
